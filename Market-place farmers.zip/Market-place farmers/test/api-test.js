/**
 * FarmDirect Automated End-to-End API Test Suite
 * Problem Statement: HACK-P309
 * Verifies all 14 mandatory test cases without third-party test runners
 */

const BASE_URL = 'http://localhost:5000/api';

const runTests = async () => {
  let passed = 0;
  let failed = 0;

  const assert = (condition, testName, details = '') => {
    if (condition) {
      console.log(`  ✅ PASS: ${testName}`);
      passed++;
    } else {
      console.error(`  ❌ FAIL: ${testName} ${details ? `(${details})` : ''}`);
      failed++;
    }
  };

  console.log('\n======================================================');
  console.log('🌾 STARTING FARMDIRECT AUTOMATED API INTEGRATION TESTS');
  console.log('======================================================\n');

  try {
    // 1. Health check
    console.log('📋 Test Group 1: Server Health & Status');
    const healthRes = await fetch(`${BASE_URL}/health`);
    const health = await healthRes.json();
    assert(healthRes.status === 200 && health.status === 'healthy', 'GET /api/health returns 200 OK');

    // 2. User Registration
    console.log('\n📋 Test Group 2: Authentication & Validation');
    const testFarmerEmail = `farmer_${Date.now()}@test.com`;
    const regFarmerRes = await fetch(`${BASE_URL}/auth/register`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        name: 'Test Farmer John',
        email: testFarmerEmail,
        password: 'Password@123',
        role: 'farmer',
        phone: '+91 98888 77777',
        address: 'Test Organic Farm, Nashik'
      })
    });
    const regFarmer = await regFarmerRes.json();
    assert(regFarmerRes.status === 201 && regFarmer.token, 'Register new farmer returns 201 with JWT token');
    const farmerToken = regFarmer.token;
    const farmerId = regFarmer.user.id;

    // Duplicate email test
    const dupRes = await fetch(`${BASE_URL}/auth/register`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        name: 'Duplicate Farmer',
        email: testFarmerEmail,
        password: 'Password@123',
        role: 'farmer'
      })
    });
    assert(dupRes.status === 409, 'Duplicate email registration is rejected with 409 Conflict');

    // Invalid role test
    const invalidRoleRes = await fetch(`${BASE_URL}/auth/register`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        name: 'Hacker Admin',
        email: `hacker_${Date.now()}@test.com`,
        password: 'Password@123',
        role: 'admin'
      })
    });
    assert(invalidRoleRes.status === 400, 'Public admin registration is blocked with 400 Bad Request');

    // Register Buyer
    const testBuyerEmail = `buyer_${Date.now()}@test.com`;
    const regBuyerRes = await fetch(`${BASE_URL}/auth/register`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        name: 'Test Buyer Alice',
        email: testBuyerEmail,
        password: 'Password@123',
        role: 'buyer',
        phone: '+91 91111 22222',
        address: 'Apartment 5B, Pune'
      })
    });
    const regBuyer = await regBuyerRes.json();
    assert(regBuyerRes.status === 201 && regBuyer.token, 'Register new buyer returns 201 with JWT token');
    const buyerToken = regBuyer.token;

    // Login test with correct credentials
    const loginRes = await fetch(`${BASE_URL}/auth/login`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        email: testFarmerEmail,
        password: 'Password@123'
      })
    });
    const loginData = await loginRes.json();
    assert(loginRes.status === 200 && loginData.token, 'Login with correct credentials succeeds');

    // Login test with wrong password
    const wrongLoginRes = await fetch(`${BASE_URL}/auth/login`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        email: testFarmerEmail,
        password: 'WrongPassword'
      })
    });
    assert(wrongLoginRes.status === 401, 'Login with incorrect password returns 401 Unauthorized');

    // 3. Products Management
    console.log('\n📋 Test Group 3: Product Management & Permissions');
    // Unauthorized product creation (no token)
    const noAuthProdRes = await fetch(`${BASE_URL}/products`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ name: 'Strawberries', category: 'Fruits', price: 100, quantity: 50 })
    });
    assert(noAuthProdRes.status === 401, 'Product creation without token is blocked with 401');

    // Forbidden product creation (buyer trying to create product)
    const buyerProdRes = await fetch(`${BASE_URL}/products`, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        'Authorization': `Bearer ${buyerToken}`
      },
      body: JSON.stringify({ name: 'Buyer Crop', category: 'Vegetables', price: 50, quantity: 20 })
    });
    assert(buyerProdRes.status === 403, 'Buyer forbidden from creating products with 403 Forbidden');

    // Farmer creates product
    const createProdRes = await fetch(`${BASE_URL}/products`, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        'Authorization': `Bearer ${farmerToken}`
      },
      body: JSON.stringify({
        name: 'Fresh Farm Broccoli',
        category: 'Vegetables',
        price: 45.0,
        quantity: 100.0,
        unit: 'kg',
        description: 'Crisp green farm-grown organic broccoli.'
      })
    });
    const createdProd = await createProdRes.json();
    assert(createProdRes.status === 201 && createdProd.product.id, 'Farmer creates product returns 201 Created');
    const testProductId = createdProd.product.id;

    // Public list products & filter test
    const listRes = await fetch(`${BASE_URL}/products?category=Vegetables&search=Broccoli`);
    const listData = await listRes.json();
    assert(listData.products.some(p => p.id === testProductId), 'Search and category filters return matching products');

    // Update product
    const updateRes = await fetch(`${BASE_URL}/products/${testProductId}`, {
      method: 'PUT',
      headers: {
        'Content-Type': 'application/json',
        'Authorization': `Bearer ${farmerToken}`
      },
      body: JSON.stringify({
        price: 42.0,
        quantity: 95.0
      })
    });
    const updateData = await updateRes.json();
    assert(updateRes.status === 200 && updateData.product.price === 42.0, 'Farmer updates product details successfully');

    // 4. Order Lifecycle & Stock Logic
    console.log('\n📋 Test Group 4: Order Lifecycle & Atomic Stock Deduction');
    // Insufficient stock test
    const excessOrderRes = await fetch(`${BASE_URL}/orders`, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        'Authorization': `Bearer ${buyerToken}`
      },
      body: JSON.stringify({
        product_id: testProductId,
        quantity: 99999
      })
    });
    assert(excessOrderRes.status === 400, 'Ordering more than available stock is rejected with 400');

    // Valid order placement (Buyer orders 20 kg Broccoli at ₹42/kg)
    const validOrderRes = await fetch(`${BASE_URL}/orders`, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        'Authorization': `Bearer ${buyerToken}`
      },
      body: JSON.stringify({
        product_id: testProductId,
        quantity: 20,
        delivery_address: 'Apartment 5B, Main Road, Pune',
        notes: 'Please pack in fresh eco-friendly bags.'
      })
    });
    const orderData = await validOrderRes.json();
    assert(
      validOrderRes.status === 201 && orderData.order.total_price === 840,
      'Order created with accurate backend total price calculation (20 * 42 = ₹840)'
    );
    const testOrderId = orderData.order.id;

    // Verify stock deduction
    const checkStockRes = await fetch(`${BASE_URL}/products/${testProductId}`);
    const checkStock = await checkStockRes.json();
    assert(
      checkStock.product.quantity === 75,
      `Product stock automatically reduced from 95 to 75 (Current: ${checkStock.product.quantity})`
    );

    // Farmer views incoming orders
    const farmerOrdersRes = await fetch(`${BASE_URL}/orders/my`, {
      headers: { 'Authorization': `Bearer ${farmerToken}` }
    });
    const farmerOrders = await farmerOrdersRes.json();
    assert(
      farmerOrders.orders.some(o => o.id === testOrderId),
      'Farmer can view incoming orders for their products'
    );

    // Farmer updates order status to 'Accepted'
    const statusUpdateRes = await fetch(`${BASE_URL}/orders/${testOrderId}/status`, {
      method: 'PATCH',
      headers: {
        'Content-Type': 'application/json',
        'Authorization': `Bearer ${farmerToken}`
      },
      body: JSON.stringify({ status: 'Accepted' })
    });
    const statusUpdateData = await statusUpdateRes.json();
    assert(
      statusUpdateRes.status === 200 && statusUpdateData.order.status === 'Accepted',
      'Farmer updates order status to "Accepted"'
    );

    // Buyer sees updated order status in their history
    const buyerOrdersRes = await fetch(`${BASE_URL}/orders/my`, {
      headers: { 'Authorization': `Bearer ${buyerToken}` }
    });
    const buyerOrders = await buyerOrdersRes.json();
    const updatedBuyerOrder = buyerOrders.orders.find(o => o.id === testOrderId);
    assert(
      updatedBuyerOrder && updatedBuyerOrder.status === 'Accepted',
      'Buyer sees real-time updated order status "Accepted" in their history'
    );

    // Delete product
    const delProdRes = await fetch(`${BASE_URL}/products/${testProductId}`, {
      method: 'DELETE',
      headers: { 'Authorization': `Bearer ${farmerToken}` }
    });
    assert(delProdRes.status === 200, 'Farmer can delete their product listing');

    console.log('\n======================================================');
    console.log(`📊 TEST SUMMARY: ${passed} PASSED, ${failed} FAILED`);
    console.log('======================================================\n');

    if (failed > 0) {
      process.exit(1);
    } else {
      process.exit(0);
    }
  } catch (err) {
    console.error('💥 Test execution error:', err);
    process.exit(1);
  }
};

runTests();

