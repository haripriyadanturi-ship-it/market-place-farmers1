const bcrypt = require('bcryptjs');
const { run, get, initDb } = require('./db');

const seedData = async (forceReset = false) => {
  await initDb();

  const userCount = await get('SELECT COUNT(*) as count FROM users');
  if (userCount.count > 0 && !forceReset) {
    console.log('ℹ️ Database already contains data. Skipping automatic seed.');
    return;
  }

  if (forceReset) {
    console.log('⚠️ Force reset requested. Clearing tables...');
    await run('DELETE FROM orders');
    await run('DELETE FROM products');
    await run('DELETE FROM users');
  }

  console.log('🌱 Seeding initial demo users...');
  const salt = await bcrypt.genSalt(10);
  const farmerPass = await bcrypt.hash('Farmer@123', salt);
  const buyerPass = await bcrypt.hash('Buyer@123', salt);
  const adminPass = await bcrypt.hash('Admin@123', salt);

  // Seed Users
  const f1 = await run(
    `INSERT INTO users (name, email, password_hash, role, phone, address) 
     VALUES (?, ?, ?, ?, ?, ?)`,
    ['Ramesh Patel (Greenfield Organics)', 'farmer.ramesh@farmdirect.com', farmerPass, 'farmer', '+91 98230 11223', 'Village Ozar, Nashik, Maharashtra']
  );

  const f2 = await run(
    `INSERT INTO users (name, email, password_hash, role, phone, address) 
     VALUES (?, ?, ?, ?, ?, ?)`,
    ['Suresh Kumar (Krishna Valley Farms)', 'farmer.suresh@farmdirect.com', farmerPass, 'farmer', '+91 94170 88990', 'Gurdaspur, Punjab']
  );

  const b1 = await run(
    `INSERT INTO users (name, email, password_hash, role, phone, address) 
     VALUES (?, ?, ?, ?, ?, ?)`,
    ['Anita Sharma', 'anita.buyer@farmdirect.com', buyerPass, 'buyer', '+91 98765 43210', 'B-402 Green Meadows, Baner, Pune']
  );

  const b2 = await run(
    `INSERT INTO users (name, email, password_hash, role, phone, address) 
     VALUES (?, ?, ?, ?, ?, ?)`,
    ['Vikram Singh', 'vikram.buyer@farmdirect.com', buyerPass, 'buyer', '+91 91234 56789', 'Plot 12, Sector 17, Navi Mumbai']
  );

  const admin = await run(
    `INSERT INTO users (name, email, password_hash, role, phone, address) 
     VALUES (?, ?, ?, ?, ?, ?)`,
    ['FarmDirect Administrator', 'admin@farmdirect.com', adminPass, 'admin', '+91 99999 00000', 'HQ Central Hub, New Delhi']
  );

  console.log('🌱 Seeding initial agricultural products...');
  const products = [
    {
      farmer_id: f1.lastID,
      name: 'Organic Vine-Ripened Tomatoes',
      category: 'Vegetables',
      price: 35.0,
      quantity: 450,
      unit: 'kg',
      description: 'Naturally grown farm-fresh red tomatoes, harvested this morning without synthetic pesticides. Juicy, rich in lycopene, perfect for curries and salads.',
      image_url: 'https://images.unsplash.com/photo-1546470427-e26264be0b11?auto=format&fit=crop&w=600&q=80'
    },
    {
      farmer_id: f1.lastID,
      name: 'Farm Fresh Jyoti Potatoes',
      category: 'Vegetables',
      price: 24.0,
      quantity: 900,
      unit: 'kg',
      description: 'Medium-to-large size, firm and unblemished freshly dug Jyoti table potatoes. Cleaned and graded.',
      image_url: 'https://images.unsplash.com/photo-1518977676601-b53f82aba655?auto=format&fit=crop&w=600&q=80'
    },
    {
      farmer_id: f1.lastID,
      name: 'Tender Fresh Spinach (Palak)',
      category: 'Vegetables',
      price: 20.0,
      quantity: 180,
      unit: 'bunch',
      description: 'Lush green pesticide-free spinach bunches. Rich in iron, vitamins, and minerals. Hand-picked at dawn.',
      image_url: 'https://images.unsplash.com/photo-1576045057995-568f588f82fb?auto=format&fit=crop&w=600&q=80'
    },
    {
      farmer_id: f1.lastID,
      name: 'Pure Desi A2 Cow Ghee (Bilona)',
      category: 'Dairy',
      price: 950.0,
      quantity: 40,
      unit: 'kg',
      description: 'Traditional Vedic Bilona method churned butter turned into aromatic golden granulated A2 Gir Cow ghee.',
      image_url: 'https://images.unsplash.com/photo-1628088062854-d1870b4553da?auto=format&fit=crop&w=600&q=80'
    },
    {
      farmer_id: f2.lastID,
      name: 'Aromatic Sharbati Wheat Grains',
      category: 'Grains',
      price: 48.0,
      quantity: 1500,
      unit: 'kg',
      description: 'The golden grain of Sehore/Punjab, high protein content, sun-dried, cleaned, creates the softest rotis.',
      image_url: 'https://images.unsplash.com/photo-1574323347407-f5e1ad6d020b?auto=format&fit=crop&w=600&q=80'
    },
    {
      farmer_id: f2.lastID,
      name: 'Traditional Basmati Rice (1121)',
      category: 'Grains',
      price: 88.0,
      quantity: 800,
      unit: 'kg',
      description: 'Extra-long grain naturally aged 1121 Basmati rice with authentic delicate aroma. Non-sticky when cooked.',
      image_url: 'https://images.unsplash.com/photo-1586201375761-83865001e31c?auto=format&fit=crop&w=600&q=80'
    },
    {
      farmer_id: f2.lastID,
      name: 'Crisp Shimla Royal Delicious Apples',
      category: 'Fruits',
      price: 150.0,
      quantity: 350,
      unit: 'kg',
      description: 'Direct from Himachal high-altitude orchards. Sweet, juicy, natural wax only, naturally ripened.',
      image_url: 'https://images.unsplash.com/photo-1560806887-1e4cd0b6cbd6?auto=format&fit=crop&w=600&q=80'
    },
    {
      farmer_id: f2.lastID,
      name: 'Nagpur Sweet Mandarin Oranges',
      category: 'Fruits',
      price: 65.0,
      quantity: 420,
      unit: 'kg',
      description: 'Juicy, sun-kissed Nagpur citrus with balanced sweet & tangy flavor. High vitamin C.',
      image_url: 'https://images.unsplash.com/photo-1611080626919-7cf5a9dbab5b?auto=format&fit=crop&w=600&q=80'
    },
    {
      farmer_id: f1.lastID,
      name: 'Unpolished High-Protein Toor Dal',
      category: 'Pulses',
      price: 145.0,
      quantity: 600,
      unit: 'kg',
      description: 'Pigeon pea lentils with natural coat intact without water/oil polish. High protein and nutritional fiber.',
      image_url: 'https://images.unsplash.com/photo-1585994192701-f1a505c817ea?auto=format&fit=crop&w=600&q=80'
    },
    {
      farmer_id: f1.lastID,
      name: 'Organic Salem Turmeric Powder',
      category: 'Spices',
      price: 210.0,
      quantity: 120,
      unit: 'kg',
      description: 'Rich in active curcumin (min 3.5%), sun-cured and stone-ground turmeric. Authentic vibrant golden color.',
      image_url: 'https://images.unsplash.com/photo-1615485290382-441e4d049cb5?auto=format&fit=crop&w=600&q=80'
    }
  ];

  const insertedProducts = [];
  for (const p of products) {
    const res = await run(
      `INSERT INTO products (farmer_id, name, category, price, quantity, unit, description, image_url)
       VALUES (?, ?, ?, ?, ?, ?, ?, ?)`,
      [p.farmer_id, p.name, p.category, p.price, p.quantity, p.unit, p.description, p.image_url]
    );
    insertedProducts.push({ id: res.lastID, ...p });
  }

  console.log('🌱 Seeding initial demo orders...');
  // Seed sample orders
  // Order 1: Anita bought 25 kg Tomatoes from Ramesh
  await run(
    `INSERT INTO orders (buyer_id, product_id, quantity, total_price, status, delivery_address, notes)
     VALUES (?, ?, ?, ?, ?, ?, ?)`,
    [b1.lastID, insertedProducts[0].id, 25, 25 * 35.0, 'Pending', 'B-402 Green Meadows, Baner, Pune', 'Please pack in sturdy crates. Need morning delivery.']
  );

  // Order 2: Vikram bought 50 kg Basmati Rice from Suresh
  await run(
    `INSERT INTO orders (buyer_id, product_id, quantity, total_price, status, delivery_address, notes)
     VALUES (?, ?, ?, ?, ?, ?, ?)`,
    [b2.lastID, insertedProducts[5].id, 50, 50 * 88.0, 'Accepted', 'Plot 12, Sector 17, Navi Mumbai', 'Standard delivery']
  );

  // Order 3: Anita bought 5 kg Desi Cow Ghee from Ramesh
  await run(
    `INSERT INTO orders (buyer_id, product_id, quantity, total_price, status, delivery_address, notes)
     VALUES (?, ?, ?, ?, ?, ?, ?)`,
    [b1.lastID, insertedProducts[3].id, 5, 5 * 950.0, 'Shipped', 'B-402 Green Meadows, Baner, Pune', 'Fragile glass jar packing please.']
  );

  console.log('🎉 Seed data successfully inserted!');
};

if (require.main === module) {
  const force = process.argv.includes('--force');
  seedData(force)
    .then(() => {
      console.log('✅ Seeding completed.');
      process.exit(0);
    })
    .catch((err) => {
      console.error('❌ Seeding failed:', err);
      process.exit(1);
    });
}

module.exports = { seedData };

