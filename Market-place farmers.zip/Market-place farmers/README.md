# FarmDirect — Direct Agricultural Marketplace
> **College Internal & External Hackathon Submission**  
> **Problem Statement ID:** `HACK-P309`  
> **Tagline:** *Fresh from farms, directly to you.*  

![Node.js](https://img.shields.io/badge/Node.js-v24.x-339933?style=flat&logo=node.js)
![Express.js](https://img.shields.io/badge/Express.js-v4.x-000000?style=flat&logo=express)
![SQLite](https://img.shields.io/badge/SQLite-v3-003B57?style=flat&logo=sqlite)
![JWT](https://img.shields.io/badge/Authentication-JWT%20%2B%20bcrypt-black?style=flat)
![Tests](https://img.shields.io/badge/Tests-19%20Passing-brightgreen?style=flat)

---

## 1. Project Overview
**FarmDirect** is a full-stack digital agricultural marketplace that disintermediates the farm-to-table supply chain. By allowing farmers to list crops directly and buyers (consumers, restaurants, grocery retailers) to purchase at fair farm-gate prices, the platform eliminates predatory middlemen commissions (saving 30%–50%), prevents food wastage, and guarantees inventory accuracy through atomic database transactions.

---

## 2. Key Features

- **Direct Farmer-to-Buyer Trade:** 0% middleman margin, authentic crop provenance, and wholesale farm pricing.
- **Role-Based JWT Authentication:** Separate dashboards and permissions for **Farmers** and **Buyers** secured via `bcryptjs` (salt rounds 10) and JSON Web Tokens.
- **Atomic Inventory & Stock Locks:** Order placement uses SQLite transactions (`BEGIN IMMEDIATE TRANSACTION`, `COMMIT`, `ROLLBACK`) to prevent overselling and guarantee inventory consistency.
- **Backend Price Calculation:** Order subtotals and totals are computed strictly on the server to prevent client-side tampering.
- **Live Search & Category Filtering:** Instant debounced search by crop name or description, category pills (Vegetables, Fruits, Grains, Pulses, Dairy, Spices), and price/name sorting.
- **Farmer Inventory Management:** Real-time metrics (Listed Crops, Barn Stock, Orders Received, Gross Revenue), product CRUD with image support, and order status management (`Pending` -> `Accepted` -> `Shipped` -> `Completed` -> `Rejected`).
- **Buyer Order Tracking:** Live order history with status pills and cancellation support (which safely returns reserved stock to the farmer).
- **Admin & Hackathon Evaluator Tools:** Protected admin overview and a one-click **"Reset Seed Data"** tool for clean hackathon presentations.
- **Quick Demo Login:** One-click pre-filled logins for judges (Farmer Ramesh, Buyer Anita, Admin).

---

## 3. Technology Stack

- **Frontend:** Semantic HTML5, Modern Responsive CSS3 (Flexbox/Grid, CSS custom variables, earthy green palette), Vanilla JavaScript (ES6+ SPA).
- **Backend:** Node.js & Express.js REST API with centralized error handling.
- **Database:** SQLite3 (`marketplace.db`) with foreign key enforcement and transaction atomicity.
- **Security:** JWT (`jsonwebtoken`), `bcryptjs` password hashing, parameterized SQL queries.
- **Testing:** Automated integration test suite (`test/api-test.js`) and Postman Collection (`postman_collection.json`).

---

## 4. Project Folder Structure

```
Market-place farmers/
├── public/                     # Frontend Client Files
│   ├── index.html              # Single Page Application HTML5 structure
│   ├── style.css               # Professional earthy green responsive stylesheet
│   └── app.js                  # Vanilla JS SPA controller & API client
├── routes/                     # Express.js REST API Route Handlers
│   ├── auth.js                 # Registration, login, profile (/api/auth)
│   ├── products.js             # Crop listing, CRUD, filtering (/api/products)
│   ├── orders.js               # Order placement & status updates (/api/orders)
│   └── admin.js                # Protected analytics & demo reset (/api/admin)
├── middleware/
│   └── authMiddleware.js       # JWT verification & role authorization
├── database/
│   ├── db.js                   # SQLite connection, promises & schema init
│   ├── seed.js                 # Realistic agricultural demo data seeder
│   └── marketplace.db          # Auto-generated SQLite database file
├── test/
│   └── api-test.js             # Automated 19-point integration test suite
├── docs/                       # Comprehensive Hackathon Documentation
│   ├── project-documentation.md # Formal problem definition & design spec
│   ├── api-documentation.md     # REST API endpoint reference
│   ├── database-design.md       # Relational schema & transaction logic
│   ├── team-contribution.md     # 4-member role division & viva defense
│   └── demo-video-script.md     # 2-3 minute video walkthrough script
├── server.js                   # Main Express application entrypoint
├── postman_collection.json     # Pre-configured Postman test collection
├── package.json                # Dependencies & npm scripts
├── .env.example                # Environment variables template
├── .gitignore                  # Git exclusions (node_modules, db, env)
└── README.md                   # This project guide
```

---

## 5. Quick Start & Installation

### Prerequisites
- [Node.js](https://nodejs.org/) (Version 18.x, 20.x, or 24.x)
- npm (Version 9.x or higher)

### 1. Clone or Open Project
```bash
cd "Market-place farmers"
```

### 2. Install Dependencies
```bash
npm install
```

### 3. Configure Environment Variables
Copy `.env.example` to `.env`:
```bash
# On Windows PowerShell
Copy-Item .env.example .env
```
Default `.env` configuration:
```env
PORT=5000
NODE_ENV=development
JWT_SECRET=farmdirect_hackathon_jwt_secret_key_2026_super_secure
DB_PATH=./database/marketplace.db
```

### 4. Run the Application
```bash
npm start
```
The server will automatically:
1. Initialize SQLite schema in `./database/marketplace.db`.
2. Seed initial demo farmers, buyers, agricultural produce, and sample orders.
3. Start listening at **`http://localhost:5000`**.

Open your browser and navigate to: **`http://localhost:5000`**

---

## 6. Pre-Configured Demo Accounts (For Evaluators)

| Role | Name | Email | Password |
| :--- | :--- | :--- | :--- |
| **Farmer** | Ramesh Patel (Greenfield Organics) | `farmer.ramesh@farmdirect.com` | `Farmer@123` |
| **Buyer** | Anita Sharma (Pune) | `anita.buyer@farmdirect.com` | `Buyer@123` |
| **Admin** | System Administrator | `admin@farmdirect.com` | `Admin@123` |

*Tip: Click the **"Quick Demo Login"** button on the top announcement bar to auto-login instantly!*

---

## 7. Running Automated Tests

Run the built-in 19-assertion integration test suite:
```bash
# Ensure server is running in another terminal, or run:
npm test
```
**Test Coverage Includes:**
- Server health & status check
- Farmer & Buyer registration
- Duplicate email conflict rejection (`409 Conflict`)
- Public admin registration blocking (`400 Bad Request`)
- Password verification & invalid credential rejection (`401 Unauthorized`)
- Token generation & route access guards
- Produce listing creation & unauthorized access blocks (`403 Forbidden`)
- Search queries & category filtering
- Product detail editing & listing deletion
- Insufficient inventory rejection (`400 Bad Request`)
- Atomic order placement with server-side pricing
- Immediate stock deduction verification
- Farmer order status transition (`Pending` -> `Accepted`)
- Buyer real-time order history tracking

---

## 8. Postman Collection
Import `postman_collection.json` into Postman. It includes pre-configured tests and environment scripts that automatically save authentication tokens upon login.

---

## 9. API Endpoint Reference

| Method | Endpoint | Access | Description |
| :--- | :--- | :--- | :--- |
| `GET` | `/api/health` | Public | System uptime & health status |
| `POST` | `/api/auth/register` | Public | Register new farmer or buyer |
| `POST` | `/api/auth/login` | Public | Login & receive JWT token |
| `GET` | `/api/auth/me` | Protected | Fetch authenticated user profile |
| `GET` | `/api/products` | Public | Discover crops with search & filter |
| `GET` | `/api/products/:id` | Public | View individual crop details |
| `POST` | `/api/products` | Farmer / Admin | List new agricultural produce |
| `PUT` | `/api/products/:id` | Farmer / Admin | Update owned produce details |
| `DELETE` | `/api/products/:id` | Farmer / Admin | Delete produce listing |
| `POST` | `/api/orders` | Buyer / Admin | Atomically place direct order |
| `GET` | `/api/orders/my` | Authenticated | View role-specific orders |
| `PATCH` | `/api/orders/:id/status` | Authenticated | Transition order lifecycle status |
| `GET` | `/api/admin/stats` | Admin | Platform metrics & GMV revenue |
| `GET` | `/api/admin/users` | Admin | View registered users |
| `POST` | `/api/admin/reset-demo` | Admin | Reset database to initial seed |

---

## 10. Four-Member Team Contribution

| Member | Role | Core Deliverables |
| :--- | :--- | :--- |
| **Member 1** | Frontend & UI/UX | Website structure (`index.html`), responsive styles (`style.css`), order & product modals, category pills, toast notifications. |
| **Member 2** | Backend & Security | Server bootstrap (`server.js`), authentication routing (`auth.js`), JWT middleware & role guards (`authMiddleware.js`). |
| **Member 3** | Database & Core APIs | SQLite schema (`db.js`), seed data (`seed.js`), product CRUD (`products.js`), atomic order transactions (`orders.js`). |
| **Member 4** | QA, Docs & Video | Automated test suite (`test/api-test.js`), Postman collection, technical documentation (`docs/*`), demo video script. |

---

## 11. Instructions to Upload to GitHub

Follow these simple commands to push this project to your team's GitHub repository:

```bash
# 1. Initialize git repository (if not already initialized)
git init

# 2. Stage all files (excluding node_modules and .env via .gitignore)
git add .

# 3. Create initial commit
git commit -m "feat: complete working FarmDirect prototype for HACK-P309"

# 4. Set main branch
git branch -M main

# 5. Link your team's GitHub repository (replace with your repository URL)
git remote add origin https://github.com/<YOUR_GITHUB_USERNAME>/<YOUR_REPOSITORY_NAME>.git

# 6. Push code to GitHub
git push -u origin main
```

---

## 12. Evaluation Summary (Problem Statement: HACK-P309)
FarmDirect fulfills 100% of the hackathon requirements:
- Functional working prototype with live SQLite database.
- Complete bidirectional workflow (Farmer lists produce -> Buyer searches & orders -> Atomic inventory decrement -> Farmer accepts order -> Buyer tracks status).
- 19 automated integration tests passing.
- Postman API collection ready for demonstration.
- Detailed demonstration video script and technical documentation.

