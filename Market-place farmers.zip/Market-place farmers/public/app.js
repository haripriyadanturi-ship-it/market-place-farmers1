/**
 * FarmDirect — Agricultural Marketplace Client Application
 * Problem Statement: HACK-P309
 * Vanilla JS SPA with JWT State, Real-time DOM Rendering & API Integration
 */

const API_BASE = '/api';

class FarmDirectApp {
  constructor() {
    this.token = localStorage.getItem('farmdirect_token') || null;
    this.currentUser = JSON.parse(localStorage.getItem('farmdirect_user') || 'null');

    // UI & Filter State
    this.currentView = 'home';
    this.products = [];
    this.orders = [];
    this.currentCategory = 'all';
    this.searchQuery = '';
    this.sortBy = 'newest';
    this.searchDebounceTimer = null;
    this.currentOrderProduct = null;

    this.sampleImages = {
      tomatoes: 'https://images.unsplash.com/photo-1546470427-e26264be0b11?auto=format&fit=crop&w=600&q=80',
      mangoes: 'https://images.unsplash.com/photo-1553279768-865429fa0078?auto=format&fit=crop&w=600&q=80',
      rice: 'https://images.unsplash.com/photo-1586201375761-83865001e31c?auto=format&fit=crop&w=600&q=80',
      spinach: 'https://images.unsplash.com/photo-1576045057995-568f588f82fb?auto=format&fit=crop&w=600&q=80'
    };

    this.init();
  }

  /**
   * Application bootstrap
   */
  async init() {
    this.bindEvents();
    this.updateAuthUI();

    // Verify token with server if present
    if (this.token) {
      await this.validateSession();
    }

    // Initial products load
    await this.loadProducts();

    // Check URL hash for routing
    const hash = window.location.hash.replace('#', '');
    if (hash && ['marketplace', 'how-it-works', 'benefits', 'dashboard', 'orders', 'admin'].includes(hash)) {
      this.navigate(hash);
    } else {
      this.navigate('home');
    }
  }

  /**
   * Bind DOM event listeners
   */
  bindEvents() {
    // Mobile navigation toggle
    const mobileToggle = document.getElementById('mobile-toggle');
    if (mobileToggle) {
      mobileToggle.addEventListener('click', () => {
        document.getElementById('main-nav').classList.toggle('mobile-open');
      });
    }

    // Quick demo modal button in announcement bar
    const quickDemoBtn = document.getElementById('quick-demo-btn');
    if (quickDemoBtn) {
      quickDemoBtn.addEventListener('click', () => {
        this.openAuthModal('login');
      });
    }

    // Global click listener to close dropdowns when clicking outside
    document.addEventListener('click', (e) => {
      const userMenu = document.getElementById('auth-logged-in');
      const dropdown = document.getElementById('user-dropdown');
      if (userMenu && dropdown && !userMenu.contains(e.target)) {
        dropdown.classList.add('hidden');
      }
    });
  }

  /**
   * Authenticated API helper
   */
  async fetchAPI(endpoint, options = {}) {
    const headers = {
      'Content-Type': 'application/json',
      ...(options.headers || {})
    };

    if (this.token) {
      headers['Authorization'] = `Bearer ${this.token}`;
    }

    try {
      const response = await fetch(`${API_BASE}${endpoint}`, {
        ...options,
        headers
      });

      const data = await response.json().catch(() => ({ success: false, message: 'Server returned non-JSON response' }));

      if (response.status === 401 && this.token) {
        this.showToast('Session expired. Please log in again.', 'error');
        this.logout();
        return { success: false, ...data };
      }

      return {
        ok: response.ok,
        status: response.status,
        ...data
      };
    } catch (err) {
      console.error('API Fetch Error:', err);
      this.showToast('Network error: Unable to reach FarmDirect server.', 'error');
      return { ok: false, success: false, message: err.message };
    }
  }

  /**
   * Verify session token on refresh
   */
  async validateSession() {
    const res = await this.fetchAPI('/auth/me');
    if (res.ok && res.user) {
      this.currentUser = res.user;
      localStorage.setItem('farmdirect_user', JSON.stringify(res.user));
      this.updateAuthUI();
    } else {
      this.logout();
    }
  }

  /**
   * Synchronize UI with Authentication State
   */
  updateAuthUI() {
    const loggedOutEl = document.getElementById('auth-logged-out');
    const loggedInEl = document.getElementById('auth-logged-in');
    const dashboardNavLi = document.getElementById('nav-dashboard-li');
    const ordersNavLi = document.getElementById('nav-orders-li');
    const adminNavLi = document.getElementById('nav-admin-li');

    if (this.currentUser && this.token) {
      loggedOutEl.classList.add('hidden');
      loggedInEl.classList.remove('hidden');

      // Populate user chip
      document.getElementById('user-display-name').textContent = this.currentUser.name;
      document.getElementById('user-display-role').textContent = this.currentUser.role;
      document.getElementById('user-avatar').textContent = (this.currentUser.name || 'U')[0].toUpperCase();
      document.getElementById('user-dropdown-email').textContent = this.currentUser.email;
      document.getElementById('user-dropdown-role').textContent = `Role: ${this.currentUser.role.toUpperCase()}`;

      // Role specific navigation
      if (this.currentUser.role === 'farmer') {
        dashboardNavLi.classList.remove('hidden');
        document.getElementById('nav-dashboard-label').textContent = 'Farmer Dashboard';
        ordersNavLi.classList.add('hidden');
        adminNavLi.classList.add('hidden');
      } else if (this.currentUser.role === 'buyer') {
        dashboardNavLi.classList.add('hidden');
        ordersNavLi.classList.remove('hidden');
        adminNavLi.classList.add('hidden');
      } else if (this.currentUser.role === 'admin') {
        dashboardNavLi.classList.remove('hidden');
        document.getElementById('nav-dashboard-label').textContent = 'Farmer Dashboard';
        ordersNavLi.classList.remove('hidden');
        adminNavLi.classList.remove('hidden');
      }
    } else {
      loggedOutEl.classList.remove('hidden');
      loggedInEl.classList.add('hidden');
      dashboardNavLi.classList.add('hidden');
      ordersNavLi.classList.add('hidden');
      adminNavLi.classList.add('hidden');
    }
  }

  /**
   * Router / View Switcher
   */
  navigate(viewName) {
    // Close mobile nav drawer
    const mainNav = document.getElementById('main-nav');
    if (mainNav) mainNav.classList.remove('mobile-open');

    // Handle scroll targets for homepage anchors
    if (['how-it-works', 'benefits'].includes(viewName)) {
      this.switchView('home');
      const targetEl = document.getElementById(viewName);
      if (targetEl) {
        setTimeout(() => targetEl.scrollIntoView({ behavior: 'smooth' }), 50);
      }
      return;
    }

    // Role Guarding
    if (viewName === 'dashboard') {
      if (!this.currentUser) {
        this.openAuthModal('login');
        this.showToast('Please log in to access your dashboard.', 'info');
        return;
      }
      if (this.currentUser.role === 'buyer') {
        this.navigate('orders');
        return;
      }
      this.loadFarmerDashboard();
    } else if (viewName === 'orders') {
      if (!this.currentUser) {
        this.openAuthModal('login');
        this.showToast('Please log in to view order history.', 'info');
        return;
      }
      this.loadBuyerOrders();
    } else if (viewName === 'admin') {
      if (!this.currentUser || this.currentUser.role !== 'admin') {
        this.showToast('Access restricted to System Administrators.', 'error');
        this.navigate('home');
        return;
      }
      this.loadAdminPanel();
    } else if (viewName === 'marketplace') {
      this.loadProducts();
    }

    this.switchView(viewName);
    window.scrollTo({ top: 0, behavior: 'smooth' });
  }

  switchView(viewName) {
    this.currentView = viewName;

    // Toggle active views
    document.querySelectorAll('.view-section').forEach(sec => {
      sec.classList.remove('active');
    });

    const activeViewEl = document.getElementById(`view-${viewName === 'dashboard' ? 'farmer-dashboard' : viewName}`);
    if (activeViewEl) {
      activeViewEl.classList.add('active');
    }

    // Update active nav links
    document.querySelectorAll('.nav-link').forEach(link => {
      link.classList.remove('active');
    });

    const matchingLink = document.querySelector(`.nav-link[href="#${viewName}"]`);
    if (matchingLink) {
      matchingLink.classList.add('active');
    }
  }

  /* ========================================================
     AUTHENTICATION LOGIC
     ======================================================== */

  openAuthModal(tab = 'login', role = 'farmer') {
    const modal = document.getElementById('auth-modal');
    modal.classList.remove('hidden');
    this.switchAuthTab(tab);
    if (tab === 'register') {
      this.handleRoleChange(role);
    }
  }

  closeAuthModal() {
    document.getElementById('auth-modal').classList.add('hidden');
  }

  closeAuthModalOnBackdrop(e) {
    if (e.target.id === 'auth-modal') {
      this.closeAuthModal();
    }
  }

  switchAuthTab(tab) {
    const loginTabBtn = document.getElementById('auth-tab-login');
    const registerTabBtn = document.getElementById('auth-tab-register');
    const loginForm = document.getElementById('login-form');
    const registerForm = document.getElementById('register-form');

    if (tab === 'login') {
      loginTabBtn.classList.add('active');
      registerTabBtn.classList.remove('active');
      loginForm.classList.remove('hidden');
      registerForm.classList.add('hidden');
    } else {
      registerTabBtn.classList.add('active');
      loginTabBtn.classList.remove('active');
      registerForm.classList.remove('hidden');
      loginForm.classList.add('hidden');
    }
  }

  handleRoleChange(role) {
    const farmerLabel = document.getElementById('role-label-farmer');
    const buyerLabel = document.getElementById('role-label-buyer');
    const radioFarmer = document.querySelector('input[name="register-role"][value="farmer"]');
    const radioBuyer = document.querySelector('input[name="register-role"][value="buyer"]');

    if (role === 'farmer') {
      farmerLabel.classList.add('selected');
      buyerLabel.classList.remove('selected');
      radioFarmer.checked = true;
    } else {
      buyerLabel.classList.add('selected');
      farmerLabel.classList.remove('selected');
      radioBuyer.checked = true;
    }
  }

  togglePasswordVisibility(inputId) {
    const input = document.getElementById(inputId);
    input.type = input.type === 'password' ? 'text' : 'password';
  }

  autofillDemo(role) {
    this.switchAuthTab('login');
    const emailInput = document.getElementById('login-email');
    const passInput = document.getElementById('login-password');

    if (role === 'farmer') {
      emailInput.value = 'farmer.ramesh@farmdirect.com';
      passInput.value = 'Farmer@123';
    } else if (role === 'buyer') {
      emailInput.value = 'anita.buyer@farmdirect.com';
      passInput.value = 'Buyer@123';
    } else if (role === 'admin') {
      emailInput.value = 'admin@farmdirect.com';
      passInput.value = 'Admin@123';
    }
  }

  async quickLogin(role) {
    let email = '';
    let pass = '';
    if (role === 'farmer') {
      email = 'farmer.ramesh@farmdirect.com';
      pass = 'Farmer@123';
    } else if (role === 'buyer') {
      email = 'anita.buyer@farmdirect.com';
      pass = 'Buyer@123';
    } else if (role === 'admin') {
      email = 'admin@farmdirect.com';
      pass = 'Admin@123';
    }

    await this.executeLogin(email, pass);
  }

  async handleLogin(e) {
    e.preventDefault();
    const email = document.getElementById('login-email').value;
    const password = document.getElementById('login-password').value;
    await this.executeLogin(email, password);
  }

  async executeLogin(email, password) {
    const btn = document.getElementById('login-submit-btn');
    if (btn) btn.disabled = true;

    const res = await this.fetchAPI('/auth/login', {
      method: 'POST',
      body: JSON.stringify({ email, password })
    });

    if (btn) btn.disabled = false;

    if (res.ok && res.token) {
      this.token = res.token;
      this.currentUser = res.user;
      localStorage.setItem('farmdirect_token', res.token);
      localStorage.setItem('farmdirect_user', JSON.stringify(res.user));

      this.closeAuthModal();
      this.updateAuthUI();
      this.showToast(`Welcome back, ${res.user.name}!`, 'success');

      // Auto-navigate to appropriate view
      if (res.user.role === 'farmer') {
        this.navigate('dashboard');
      } else if (res.user.role === 'buyer') {
        this.navigate('marketplace');
      } else if (res.user.role === 'admin') {
        this.navigate('admin');
      }
    } else {
      this.showToast(res.message || 'Login failed. Please check your credentials.', 'error');
    }
  }

  async handleRegister(e) {
    e.preventDefault();
    const roleRadio = document.querySelector('input[name="register-role"]:checked');
    const role = roleRadio ? roleRadio.value : 'farmer';
    const name = document.getElementById('reg-name').value;
    const email = document.getElementById('reg-email').value;
    const phone = document.getElementById('reg-phone').value;
    const password = document.getElementById('reg-password').value;
    const address = document.getElementById('reg-address').value;

    const btn = document.getElementById('reg-submit-btn');
    btn.disabled = true;

    const res = await this.fetchAPI('/auth/register', {
      method: 'POST',
      body: JSON.stringify({ name, email, phone, password, address, role })
    });

    btn.disabled = false;

    if (res.ok && res.token) {
      this.token = res.token;
      this.currentUser = res.user;
      localStorage.setItem('farmdirect_token', res.token);
      localStorage.setItem('farmdirect_user', JSON.stringify(res.user));

      this.closeAuthModal();
      this.updateAuthUI();
      this.showToast('Account registered successfully! Welcome to FarmDirect.', 'success');

      if (role === 'farmer') {
        this.navigate('dashboard');
      } else {
        this.navigate('marketplace');
      }
    } else {
      this.showToast(res.message || 'Registration failed.', 'error');
    }
  }

  logout() {
    this.token = null;
    this.currentUser = null;
    localStorage.removeItem('farmdirect_token');
    localStorage.removeItem('farmdirect_user');
    this.updateAuthUI();
    this.closeUserDropdown();
    this.showToast('You have been logged out.', 'info');
    this.navigate('home');
  }

  toggleUserDropdown() {
    document.getElementById('user-dropdown').classList.toggle('hidden');
  }

  closeUserDropdown() {
    const dropdown = document.getElementById('user-dropdown');
    if (dropdown) dropdown.classList.add('hidden');
  }

  /* ========================================================
     MARKETPLACE & PRODUCTS LOGIC
     ======================================================== */

  async loadProducts() {
    const badge = document.getElementById('product-count-badge');
    if (badge) badge.innerHTML = '<i class="fa-solid fa-spinner fa-spin"></i> Refreshing harvest...';

    const params = new URLSearchParams();
    if (this.currentCategory && this.currentCategory !== 'all') {
      params.append('category', this.currentCategory);
    }
    if (this.searchQuery && this.searchQuery.trim() !== '') {
      params.append('search', this.searchQuery.trim());
    }

    const endpoint = `/products${params.toString() ? `?${params.toString()}` : ''}`;
    const res = await this.fetchAPI(endpoint);

    if (res.ok && Array.isArray(res.products)) {
      this.products = res.products;
      this.renderProducts();
    } else {
      this.showToast('Failed to load products.', 'error');
    }
  }

  setCategory(category) {
    this.currentCategory = category;

    // Update active pill button
    document.querySelectorAll('.cat-pill').forEach(btn => {
      btn.classList.toggle('active', btn.dataset.category === category);
    });

    this.loadProducts();
  }

  handleSearchInput(e) {
    const val = e.target.value;
    this.searchQuery = val;

    const clearBtn = document.getElementById('clear-search-btn');
    if (clearBtn) {
      clearBtn.classList.toggle('hidden', val.length === 0);
    }

    clearTimeout(this.searchDebounceTimer);
    this.searchDebounceTimer = setTimeout(() => {
      this.loadProducts();
    }, 300);
  }

  clearSearch() {
    const input = document.getElementById('marketplace-search-input');
    if (input) input.value = '';
    this.searchQuery = '';
    document.getElementById('clear-search-btn').classList.add('hidden');
    this.loadProducts();
  }

  handleSortChange(e) {
    this.sortBy = e.target.value;
    this.renderProducts();
  }

  resetMarketplaceFilters() {
    this.clearSearch();
    this.setCategory('all');
    document.getElementById('sort-select').value = 'newest';
    this.sortBy = 'newest';
  }

  renderProducts() {
    const grid = document.getElementById('products-grid');
    const emptyState = document.getElementById('products-empty-state');
    const countBadge = document.getElementById('product-count-badge');

    if (!grid) return;

    // Sort products in-memory
    let sorted = [...this.products];
    if (this.sortBy === 'price-low') {
      sorted.sort((a, b) => a.price - b.price);
    } else if (this.sortBy === 'price-high') {
      sorted.sort((a, b) => b.price - a.price);
    } else if (this.sortBy === 'name') {
      sorted.sort((a, b) => a.name.localeCompare(b.name));
    } else {
      sorted.sort((a, b) => b.id - a.id);
    }

    // Update count badge
    if (countBadge) {
      countBadge.innerHTML = `<i class="fa-solid fa-leaf text-success"></i> ${sorted.length} Farm Products Available`;
    }

    if (sorted.length === 0) {
      grid.innerHTML = '';
      emptyState.classList.remove('hidden');
      return;
    }

    emptyState.classList.add('hidden');

    grid.innerHTML = sorted.map(product => {
      const isOutOfStock = product.quantity <= 0;
      const isLowStock = product.quantity > 0 && product.quantity < 20;

      let stockBadgeClass = 'stock-in';
      let stockBadgeText = `${product.quantity} ${product.unit} available`;
      if (isOutOfStock) {
        stockBadgeClass = 'stock-out';
        stockBadgeText = 'Sold Out';
      } else if (isLowStock) {
        stockBadgeClass = 'stock-low';
        stockBadgeText = `Only ${product.quantity} ${product.unit} left!`;
      }

      // Check if logged in user is the owner farmer
      const isOwner = this.currentUser && this.currentUser.id === product.farmer_id;

      return `
        <div class="product-card" data-id="${product.id}">
          <div class="product-card-img-wrap">
            <img src="${product.image_url || this.sampleImages.tomatoes}" alt="${this.escapeHtml(product.name)}" class="product-card-img" loading="lazy" onerror="this.src='https://images.unsplash.com/photo-1542838132-92c53300491e?auto=format&fit=crop&w=600&q=80'">
            <span class="card-category-badge">${this.escapeHtml(product.category)}</span>
            <span class="card-stock-badge ${stockBadgeClass}">${stockBadgeText}</span>
          </div>

          <div class="product-card-body">
            <h3 class="product-card-title">${this.escapeHtml(product.name)}</h3>
            <div class="farmer-tag">
              <i class="fa-solid fa-tractor"></i>
              <span>${this.escapeHtml(product.farmer_name || 'Verified Farmer')}</span>
              ${product.farmer_location ? `<span class="farmer-location-sub">• ${this.escapeHtml(product.farmer_location.split(',')[0])}</span>` : ''}
            </div>
            <p class="product-card-desc">${this.escapeHtml(product.description || 'Farm-fresh harvest grown under standard practices.')}</p>

            <div class="product-card-footer">
              <div class="price-tag">
                <span class="price-val">₹${product.price.toFixed(2)}</span>
                <span class="price-unit">per ${this.escapeHtml(product.unit)}</span>
              </div>

              ${isOwner ? `
                <button class="btn btn-outline btn-sm" onclick="app.openEditProductModal(${product.id})">
                  <i class="fa-solid fa-pen-to-square"></i> Edit
                </button>
              ` : `
                <button class="btn btn-primary btn-sm" ${isOutOfStock ? 'disabled' : ''} onclick="app.openOrderModal(${product.id})">
                  <i class="fa-solid fa-cart-shopping"></i> ${isOutOfStock ? 'Sold Out' : 'Direct Order'}
                </button>
              `}
            </div>
          </div>
        </div>
      `;
    }).join('');
  }

  /* ========================================================
     ORDER PLACEMENT LOGIC (BUYER)
     ======================================================== */

  openOrderModal(productId) {
    if (!this.currentUser) {
      this.openAuthModal('login');
      this.showToast('Please log in as a Buyer to place an order.', 'info');
      return;
    }

    if (this.currentUser.role === 'farmer') {
      this.showToast('Farmers cannot place buyer orders. Please switch to a buyer account.', 'error');
      return;
    }

    const product = this.products.find(p => p.id === productId);
    if (!product) return;

    this.currentOrderProduct = product;

    document.getElementById('order-product-id').value = product.id;
    document.getElementById('order-product-name').textContent = product.name;
    document.getElementById('order-farmer-info').textContent = `Sold directly by ${product.farmer_name} (${product.farmer_location || 'Local Farm'})`;
    document.getElementById('order-product-img').src = product.image_url || this.sampleImages.tomatoes;
    document.getElementById('order-unit-price').textContent = `₹${product.price.toFixed(2)} / ${product.unit}`;
    document.getElementById('order-stock-available').textContent = `${product.quantity} ${product.unit} Available`;
    document.getElementById('order-category-tag').textContent = product.category;
    document.getElementById('order-unit-label').textContent = product.unit;

    // Default quantity
    const defaultQty = Math.min(5, product.quantity > 0 ? product.quantity : 1);
    const qtyInput = document.getElementById('order-quantity');
    qtyInput.value = defaultQty;
    qtyInput.max = product.quantity;

    // Autofill buyer address if profile has one
    const addressInput = document.getElementById('order-address');
    addressInput.value = this.currentUser.address || '';

    this.updateOrderCalculations();

    document.getElementById('order-modal').classList.remove('hidden');
  }

  closeOrderModal() {
    document.getElementById('order-modal').classList.add('hidden');
    this.currentOrderProduct = null;
  }

  closeOrderModalOnBackdrop(e) {
    if (e.target.id === 'order-modal') {
      this.closeOrderModal();
    }
  }

  stepQuantity(delta) {
    const input = document.getElementById('order-quantity');
    let current = parseFloat(input.value) || 1;
    let nextVal = Math.max(1, current + delta);
    if (this.currentOrderProduct && nextVal > this.currentOrderProduct.quantity) {
      nextVal = this.currentOrderProduct.quantity;
      this.showToast(`Maximum available stock is ${this.currentOrderProduct.quantity} ${this.currentOrderProduct.unit}.`, 'info');
    }
    input.value = nextVal;
    this.updateOrderCalculations();
  }

  updateOrderCalculations() {
    if (!this.currentOrderProduct) return;
    const qtyInput = document.getElementById('order-quantity');
    const qty = parseFloat(qtyInput.value) || 0;
    const rate = this.currentOrderProduct.price;
    const total = qty * rate;

    document.getElementById('calc-qty').textContent = qty;
    document.getElementById('calc-rate').textContent = `₹${rate}`;
    document.getElementById('order-total-preview').textContent = `₹${total.toFixed(2)}`;
  }

  async handlePlaceOrder(e) {
    e.preventDefault();
    if (!this.currentOrderProduct) return;

    const productId = this.currentOrderProduct.id;
    const quantity = parseFloat(document.getElementById('order-quantity').value);
    const delivery_address = document.getElementById('order-address').value;
    const notes = document.getElementById('order-notes').value;

    if (quantity <= 0) {
      this.showToast('Please specify a valid quantity greater than zero.', 'error');
      return;
    }

    if (quantity > this.currentOrderProduct.quantity) {
      this.showToast(`Order quantity exceeds available stock (${this.currentOrderProduct.quantity} ${this.currentOrderProduct.unit}).`, 'error');
      return;
    }

    const btn = document.getElementById('confirm-order-btn');
    btn.disabled = true;
    btn.innerHTML = '<i class="fa-solid fa-spinner fa-spin"></i> Processing Order...';

    const res = await this.fetchAPI('/orders', {
      method: 'POST',
      body: JSON.stringify({
        product_id: productId,
        quantity,
        delivery_address,
        notes
      })
    });

    btn.disabled = false;
    btn.innerHTML = '<i class="fa-solid fa-check"></i> Confirm Direct Order';

    if (res.ok && res.order) {
      this.closeOrderModal();
      this.showToast(`🎉 Order #${res.order.id} placed successfully! Total: ₹${res.order.total_price.toFixed(2)}`, 'success');

      // Refresh products to reflect reduced stock
      await this.loadProducts();

      // Navigate to buyer's orders
      this.navigate('orders');
    } else {
      this.showToast(res.message || 'Failed to place order. Please try again.', 'error');
    }
  }

  /* ========================================================
     BUYER ORDERS MANAGEMENT
     ======================================================== */

  async loadBuyerOrders() {
    const listEl = document.getElementById('buyer-orders-list');
    const emptyEl = document.getElementById('buyer-orders-empty');

    if (!listEl) return;
    listEl.innerHTML = '<div class="text-center" style="padding: 40px;"><i class="fa-solid fa-spinner fa-spin fa-2x text-success"></i><p>Loading your orders...</p></div>';

    const res = await this.fetchAPI('/orders/my');

    if (res.ok && Array.isArray(res.orders)) {
      this.orders = res.orders;

      if (res.orders.length === 0) {
        listEl.innerHTML = '';
        emptyEl.classList.remove('hidden');
        return;
      }

      emptyEl.classList.add('hidden');

      listEl.innerHTML = res.orders.map(order => {
        const dateStr = new Date(order.created_at).toLocaleDateString('en-IN', {
          day: 'numeric',
          month: 'short',
          year: 'numeric',
          hour: '2-digit',
          minute: '2-digit'
        });

        const isCancelable = order.status === 'Pending';

        return `
          <div class="order-history-card">
            <div class="order-thumb-wrap">
              <img src="${order.product_image || this.sampleImages.tomatoes}" alt="${this.escapeHtml(order.product_name)}" onerror="this.src='https://images.unsplash.com/photo-1542838132-92c53300491e?auto=format&fit=crop&w=600&q=80'">
            </div>

            <div class="order-details-col">
              <h4>${this.escapeHtml(order.product_name)}</h4>
              <div class="order-meta-info">
                <span><strong>Order:</strong> #${order.id}</span>
                <span><strong>Farmer:</strong> ${this.escapeHtml(order.farmer_name || 'Registered Farmer')} (${order.farmer_phone || 'Contact provided on dispatch'})</span>
                <span><strong>Placed:</strong> ${dateStr}</span>
              </div>
              <div class="order-address-box">
                <i class="fa-solid fa-location-dot"></i> Delivery to: ${this.escapeHtml(order.delivery_address || 'Address provided at order time')}
                ${order.notes ? `<br><small><strong>Notes:</strong> ${this.escapeHtml(order.notes)}</small>` : ''}
              </div>
            </div>

            <div class="order-price-col">
              <span class="status-pill status-${order.status}">
                <i class="fa-solid ${this.getStatusIcon(order.status)}"></i> ${order.status}
              </span>
              <div class="order-amount-display">₹${order.total_price.toFixed(2)}</div>
              <small class="text-muted">${order.quantity} ${order.product_unit} × ₹${order.unit_price}</small>

              ${isCancelable ? `
                <button class="btn btn-outline btn-sm" style="color: var(--status-cancelled); border-color: var(--status-cancelled);" onclick="app.cancelBuyerOrder(${order.id})">
                  <i class="fa-solid fa-ban"></i> Cancel Order
                </button>
              ` : ''}
            </div>
          </div>
        `;
      }).join('');
    } else {
      this.showToast('Unable to load orders.', 'error');
    }
  }

  async cancelBuyerOrder(orderId) {
    if (!confirm(`Are you sure you want to cancel Order #${orderId}? Stock will be returned to the farmer.`)) {
      return;
    }

    const res = await this.fetchAPI(`/orders/${orderId}/status`, {
      method: 'PATCH',
      body: JSON.stringify({ status: 'Cancelled' })
    });

    if (res.ok) {
      this.showToast(`Order #${orderId} has been cancelled.`, 'info');
      await this.loadBuyerOrders();
      await this.loadProducts();
    } else {
      this.showToast(res.message || 'Could not cancel order.', 'error');
    }
  }

  /* ========================================================
     FARMER DASHBOARD & CROP INVENTORY
     ======================================================== */

  async loadFarmerDashboard() {
    if (!this.currentUser) return;

    // Header greetings
    document.getElementById('farmer-name-display').textContent = this.currentUser.name;
    document.getElementById('farmer-location-display').textContent = this.currentUser.address || 'Registered Farm Location';

    // Fetch farmer's own products
    const prodRes = await this.fetchAPI(`/products?farmer_id=${this.currentUser.id}`);
    const farmerProducts = prodRes.ok ? prodRes.products : [];

    // Fetch farmer's incoming orders
    const orderRes = await this.fetchAPI('/orders/my');
    const farmerOrders = orderRes.ok ? orderRes.orders : [];

    // Compute stats
    const totalListed = farmerProducts.length;
    const totalStock = farmerProducts.reduce((acc, p) => acc + (parseFloat(p.quantity) || 0), 0);
    const totalOrders = farmerOrders.length;
    const totalRevenue = farmerOrders
      .filter(o => !['Cancelled', 'Rejected'].includes(o.status))
      .reduce((acc, o) => acc + (parseFloat(o.total_price) || 0), 0);

    document.getElementById('farmer-stat-products').textContent = totalListed;
    document.getElementById('farmer-stat-stock').textContent = `${Math.round(totalStock)} kg/units`;
    document.getElementById('farmer-stat-orders').textContent = totalOrders;
    document.getElementById('farmer-stat-revenue').textContent = `₹${totalRevenue.toFixed(2)}`;

    document.getElementById('farmer-tab-count').textContent = totalListed;
    document.getElementById('farmer-orders-count').textContent = totalOrders;

    // Render Farmer's Listed Products Table
    this.renderFarmerProductsTable(farmerProducts);

    // Render Farmer's Incoming Orders Table
    this.renderFarmerOrdersTable(farmerOrders);
  }

  switchFarmerTab(tabName) {
    document.querySelectorAll('.dashboard-tabs .tab-btn').forEach(btn => {
      btn.classList.toggle('active', btn.dataset.tab === tabName);
    });

    document.getElementById('tab-farmer-products').classList.toggle('active', tabName === 'farmer-products');
    document.getElementById('tab-farmer-orders').classList.toggle('active', tabName === 'farmer-orders');
  }

  renderFarmerProductsTable(products) {
    const tbody = document.getElementById('farmer-products-tbody');
    const emptyEl = document.getElementById('farmer-products-empty');

    if (products.length === 0) {
      tbody.innerHTML = '';
      emptyEl.classList.remove('hidden');
      return;
    }

    emptyEl.classList.add('hidden');

    tbody.innerHTML = products.map(p => {
      const isLow = p.quantity < 20 && p.quantity > 0;
      const isOut = p.quantity <= 0;
      let stockClass = '';
      if (isOut) stockClass = 'text-accent';
      else if (isLow) stockClass = 'text-orange';
      else stockClass = 'text-success';

      const dateStr = new Date(p.created_at).toLocaleDateString('en-IN', { day: 'numeric', month: 'short', year: 'numeric' });

      return `
        <tr>
          <td>
            <div class="table-produce-cell">
              <img src="${p.image_url || this.sampleImages.tomatoes}" alt="${this.escapeHtml(p.name)}" class="table-produce-thumb" onerror="this.src='https://images.unsplash.com/photo-1542838132-92c53300491e?auto=format&fit=crop&w=600&q=80'">
              <div>
                <strong>${this.escapeHtml(p.name)}</strong>
                <small class="text-muted" style="display:block;">${p.unit}</small>
              </div>
            </div>
          </td>
          <td><span class="badge badge-subtle">${this.escapeHtml(p.category)}</span></td>
          <td><strong>₹${p.price.toFixed(2)}</strong> / ${p.unit}</td>
          <td>
            <span class="${stockClass}" style="font-weight: 700;">
              ${p.quantity} ${p.unit}
              ${isOut ? ' (Sold Out)' : isLow ? ' (Low Stock)' : ''}
            </span>
          </td>
          <td><small class="text-muted">${dateStr}</small></td>
          <td>
            <div class="action-buttons-group">
              <button class="btn btn-outline btn-sm" onclick="app.openEditProductModal(${p.id})">
                <i class="fa-solid fa-pen"></i> Edit
              </button>
              <button class="btn btn-sm btn-outline" style="color: var(--status-cancelled); border-color: var(--status-cancelled);" onclick="app.deleteProductListing(${p.id}, '${this.escapeHtml(p.name)}')">
                <i class="fa-solid fa-trash"></i>
              </button>
            </div>
          </td>
        </tr>
      `;
    }).join('');
  }

  renderFarmerOrdersTable(orders) {
    const tbody = document.getElementById('farmer-orders-tbody');
    const emptyEl = document.getElementById('farmer-orders-empty');

    if (orders.length === 0) {
      tbody.innerHTML = '';
      emptyEl.classList.remove('hidden');
      return;
    }

    emptyEl.classList.add('hidden');

    tbody.innerHTML = orders.map(order => {
      const isFinal = ['Completed', 'Cancelled', 'Rejected'].includes(order.status);

      return `
        <tr>
          <td><strong>#${order.id}</strong></td>
          <td>
            <div class="table-produce-cell">
              <img src="${order.product_image || this.sampleImages.tomatoes}" class="table-produce-thumb">
              <div>
                <strong>${this.escapeHtml(order.product_name)}</strong>
              </div>
            </div>
          </td>
          <td>
            <strong>${this.escapeHtml(order.buyer_name || 'Buyer')}</strong>
            <small class="text-muted" style="display: block;">${this.escapeHtml(order.buyer_phone || order.buyer_email || '')}</small>
            <small class="text-muted" style="display: block;"><i class="fa-solid fa-truck"></i> ${this.escapeHtml(order.delivery_address || 'Direct Delivery')}</small>
          </td>
          <td>${order.quantity} ${order.product_unit}</td>
          <td><strong class="text-success">₹${order.total_price.toFixed(2)}</strong></td>
          <td>
            <span class="status-pill status-${order.status}">
              <i class="fa-solid ${this.getStatusIcon(order.status)}"></i> ${order.status}
            </span>
          </td>
          <td>
            ${isFinal ? `<small class="text-muted">Finalized</small>` : `
              <select onchange="app.updateOrderStatus(${order.id}, this.value)" style="padding: 4px 8px; font-size: 0.82rem; border-radius: var(--radius-sm); border: 1px solid var(--border-color);">
                <option value="Pending" ${order.status === 'Pending' ? 'selected' : ''}>Pending</option>
                <option value="Accepted" ${order.status === 'Accepted' ? 'selected' : ''}>Accept Order</option>
                <option value="Shipped" ${order.status === 'Shipped' ? 'selected' : ''}>Ship Produce</option>
                <option value="Completed" ${order.status === 'Completed' ? 'selected' : ''}>Mark Completed</option>
                <option value="Rejected" ${order.status === 'Rejected' ? 'selected' : ''}>Reject Order</option>
              </select>
            `}
          </td>
        </tr>
      `;
    }).join('');
  }

  /* ========================================================
     ADD / EDIT / DELETE PRODUCT (FARMER)
     ======================================================== */

  openAddProductModal() {
    document.getElementById('product-modal-title').innerHTML = '<i class="fa-solid fa-leaf text-success"></i> List New Harvest Produce';
    document.getElementById('prod-id').value = '';
    document.getElementById('prod-name').value = '';
    document.getElementById('prod-category').value = 'Vegetables';
    document.getElementById('prod-unit').value = 'kg';
    document.getElementById('prod-price').value = '';
    document.getElementById('prod-quantity').value = '';
    document.getElementById('prod-image').value = '';
    document.getElementById('prod-desc').value = '';

    document.getElementById('product-modal').classList.remove('hidden');
  }

  openEditProductModal(productId) {
    const product = this.products.find(p => p.id === productId);
    if (!product) return;

    document.getElementById('product-modal-title').innerHTML = '<i class="fa-solid fa-pen-to-square text-success"></i> Edit Produce Listing';
    document.getElementById('prod-id').value = product.id;
    document.getElementById('prod-name').value = product.name;
    document.getElementById('prod-category').value = product.category;
    document.getElementById('prod-unit').value = product.unit;
    document.getElementById('prod-price').value = product.price;
    document.getElementById('prod-quantity').value = product.quantity;
    document.getElementById('prod-image').value = product.image_url || '';
    document.getElementById('prod-desc').value = product.description || '';

    document.getElementById('product-modal').classList.remove('hidden');
  }

  closeProductModal() {
    document.getElementById('product-modal').classList.add('hidden');
  }

  closeProductModalOnBackdrop(e) {
    if (e.target.id === 'product-modal') {
      this.closeProductModal();
    }
  }

  setSampleImage(type) {
    const input = document.getElementById('prod-image');
    if (this.sampleImages[type]) {
      input.value = this.sampleImages[type];
    }
  }

  async handleProductSubmit(e) {
    e.preventDefault();
    const id = document.getElementById('prod-id').value;
    const name = document.getElementById('prod-name').value;
    const category = document.getElementById('prod-category').value;
    const unit = document.getElementById('prod-unit').value;
    const price = parseFloat(document.getElementById('prod-price').value);
    const quantity = parseFloat(document.getElementById('prod-quantity').value);
    const image_url = document.getElementById('prod-image').value;
    const description = document.getElementById('prod-desc').value;

    const payload = { name, category, unit, price, quantity, image_url, description };
    const btn = document.getElementById('save-product-btn');
    btn.disabled = true;

    let res;
    if (id) {
      // Update
      res = await this.fetchAPI(`/products/${id}`, {
        method: 'PUT',
        body: JSON.stringify(payload)
      });
    } else {
      // Create
      res = await this.fetchAPI('/products', {
        method: 'POST',
        body: JSON.stringify(payload)
      });
    }

    btn.disabled = false;

    if (res.ok) {
      this.closeProductModal();
      this.showToast(id ? 'Product updated successfully!' : 'New harvest produce listed successfully!', 'success');
      await this.loadProducts();
      await this.loadFarmerDashboard();
    } else {
      this.showToast(res.message || 'Failed to save product.', 'error');
    }
  }

  async deleteProductListing(productId, productName) {
    if (!confirm(`Are you sure you want to delete the listing for "${productName}"?`)) {
      return;
    }

    const res = await this.fetchAPI(`/products/${productId}`, {
      method: 'DELETE'
    });

    if (res.ok) {
      this.showToast(`"${productName}" listing deleted.`, 'info');
      await this.loadProducts();
      await this.loadFarmerDashboard();
    } else {
      this.showToast(res.message || 'Failed to delete product.', 'error');
    }
  }

  async updateOrderStatus(orderId, newStatus) {
    const res = await this.fetchAPI(`/orders/${orderId}/status`, {
      method: 'PATCH',
      body: JSON.stringify({ status: newStatus })
    });

    if (res.ok) {
      this.showToast(`Order #${orderId} status updated to "${newStatus}".`, 'success');
      await this.loadFarmerDashboard();
      await this.loadProducts();
    } else {
      this.showToast(res.message || 'Failed to update order status.', 'error');
    }
  }

  /* ========================================================
     ADMIN PANEL & STATS
     ======================================================== */

  async loadAdminPanel() {
    const statsRes = await this.fetchAPI('/admin/stats');
    if (statsRes.ok && statsRes.stats) {
      document.getElementById('admin-stat-users').textContent = statsRes.stats.totalUsers;
      document.getElementById('admin-stat-farmers').textContent = statsRes.stats.totalFarmers;
      document.getElementById('admin-stat-buyers').textContent = statsRes.stats.totalBuyers;
      document.getElementById('admin-stat-revenue').textContent = `₹${statsRes.stats.totalRevenue.toFixed(2)}`;
    }

    // Load registered users
    const usersRes = await this.fetchAPI('/admin/users');
    if (usersRes.ok && Array.isArray(usersRes.users)) {
      const tbody = document.getElementById('admin-users-tbody');
      tbody.innerHTML = usersRes.users.map(u => `
        <tr>
          <td><strong>#${u.id}</strong></td>
          <td>${this.escapeHtml(u.name)}</td>
          <td>${this.escapeHtml(u.email)}</td>
          <td><span class="badge ${u.role === 'farmer' ? 'badge-farmer' : 'badge-subtle'}">${u.role.toUpperCase()}</span></td>
          <td>${this.escapeHtml(u.phone || 'N/A')}</td>
          <td><small>${this.escapeHtml(u.address || 'N/A')}</small></td>
          <td><small>${new Date(u.created_at).toLocaleDateString('en-IN')}</small></td>
        </tr>
      `).join('');
    }

    // Load all orders
    const ordersRes = await this.fetchAPI('/orders/my');
    if (ordersRes.ok && Array.isArray(ordersRes.orders)) {
      const tbody = document.getElementById('admin-orders-tbody');
      tbody.innerHTML = ordersRes.orders.map(o => `
        <tr>
          <td><strong>#${o.id}</strong></td>
          <td>${this.escapeHtml(o.product_name)}</td>
          <td>${this.escapeHtml(o.buyer_name || 'Buyer')}</td>
          <td>${this.escapeHtml(o.farmer_name || 'Farmer')}</td>
          <td>${o.quantity} ${o.product_unit}</td>
          <td><strong>₹${o.total_price.toFixed(2)}</strong></td>
          <td><span class="status-pill status-${o.status}">${o.status}</span></td>
          <td><small>${new Date(o.created_at).toLocaleDateString('en-IN')}</small></td>
        </tr>
      `).join('');
    }
  }

  switchAdminTab(tabName) {
    document.querySelectorAll('[data-admin-tab]').forEach(btn => {
      btn.classList.toggle('active', btn.dataset.adminTab === tabName);
    });

    document.getElementById('tab-admin-users').classList.toggle('active', tabName === 'admin-users');
    document.getElementById('tab-admin-orders').classList.toggle('active', tabName === 'admin-orders');
  }

  async resetDemoDatabase() {
    if (!confirm('⚠️ Are you sure you want to reset the database to clean seed state? All newly created test products and test orders will be safely restored to the initial hackathon demo dataset.')) {
      return;
    }

    const res = await this.fetchAPI('/admin/reset-demo', { method: 'POST' });
    if (res.ok) {
      this.showToast('✅ Demo database reset successfully to original seed state!', 'success');
      await this.loadProducts();
      await this.loadAdminPanel();
    } else {
      this.showToast(res.message || 'Failed to reset demo database.', 'error');
    }
  }

  /* ========================================================
     HELPERS & UTILITIES
     ======================================================== */

  getStatusIcon(status) {
    switch (status) {
      case 'Pending': return 'fa-clock';
      case 'Accepted': return 'fa-check';
      case 'Shipped': return 'fa-truck-fast';
      case 'Completed': return 'fa-circle-check';
      case 'Cancelled':
      case 'Rejected': return 'fa-xmark';
      default: return 'fa-circle-info';
    }
  }

  escapeHtml(str) {
    if (!str) return '';
    return String(str)
      .replace(/&/g, '&amp;')
      .replace(/</g, '&lt;')
      .replace(/>/g, '&gt;')
      .replace(/"/g, '&quot;')
      .replace(/'/g, '&#039;');
  }

  showToast(message, type = 'info') {
    const container = document.getElementById('toast-container');
    if (!container) return;

    const toast = document.createElement('div');
    toast.className = `toast toast-${type}`;

    let icon = 'fa-info-circle';
    if (type === 'success') icon = 'fa-circle-check';
    if (type === 'error') icon = 'fa-circle-exclamation';

    toast.innerHTML = `<i class="fa-solid ${icon}"></i> <span>${this.escapeHtml(message)}</span>`;
    container.appendChild(toast);

    setTimeout(() => {
      toast.style.opacity = '0';
      toast.style.transform = 'translateX(60px)';
      toast.style.transition = 'all 0.3s ease';
      setTimeout(() => toast.remove(), 300);
    }, 4000);
  }
}

// Global Application Instance
let app;
document.addEventListener('DOMContentLoaded', () => {
  app = new FarmDirectApp();
});

