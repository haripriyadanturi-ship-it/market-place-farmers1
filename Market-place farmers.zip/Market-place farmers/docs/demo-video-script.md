# FarmDirect — Demonstration Video Script (2–3 Minutes)
**Problem Statement ID:** HACK-P309  
**Project Title:** FarmDirect — Direct Agricultural Marketplace  
**Target Duration:** ~2 Minutes 45 Seconds  
**Audio / Video Style:** Clear voiceover with screen-recorded live application walkthrough.

---

## Storyboard & Narration Breakdown

### Scene 1: Introduction & Problem Context (0:00 – 0:25)
- **Visual on Screen:**
  - Full-screen view of the **FarmDirect Homepage** at `http://localhost:5000`.
  - Mouse hovers over the header logo and tagline: *"Fresh from farms, directly to you"*.
  - Problem Statement ID badge **HACK-P309** is prominently visible in the announcement bar.
- **Presenter Narration (Member 4):**
  > "Hello evaluators! We are team members presenting FarmDirect, built for Problem Statement HACK-P309. In the traditional agricultural market, farmers lose up to 50% of their earnings to intermediaries and commission agents, while buyers pay inflated prices for stale produce. FarmDirect is a digital marketplace that connects farmers directly with buyers, providing transparent pricing, atomic inventory guarantees, and direct order fulfillment."

---

### Scene 2: Homepage Tour & Quick Demo Feature (0:25 – 0:45)
- **Visual on Screen:**
  - Presenter scrolls through the homepage hero section, showing value statistics (100% Direct Sourcing, 0% Middleman Margin).
  - Scrolls through the 4-step "How It Works" workflow and the Farmer vs. Buyer benefits comparison.
  - Pauses on the "Quick Demo Access" banner showing one-click login options.
- **Presenter Narration (Member 1):**
  > "Our user interface is designed with an accessible earthy and green palette, fully responsive across all screens. Notice our 'Quick Demo Login' feature—custom-built for hackathon judges so you can test complete workflows with zero friction."

---

### Scene 3: Farmer Login & Crop Listing (0:45 – 1:15)
- **Visual on Screen:**
  - Click "Quick Demo Login" -> Select **Farmer Ramesh**.
  - System logs in instantly with JWT authentication and redirects to the **Farmer Dashboard**.
  - Show overview cards: Listed Products, Barn Stock, Incoming Orders, and Gross Revenue.
  - Click **"+ List New Harvest"** button.
  - Fill modal with:
    - Name: `Crisp Red Shimla Pears`
    - Category: `Fruits`
    - Price: `₹120` / kg
    - Quantity: `200` kg
    - Click sample image pill `Mangoes` or paste fruit URL.
    - Description: `Naturally grown high-altitude pears, hand-harvested this morning.`
  - Click **"Save Product Listing"**.
  - Green success toast appears; the new product immediately appears in the active listings table.
- **Presenter Narration (Member 2):**
  > "Logging in as Farmer Ramesh, we access the Farmer Dashboard. Ramesh can view real-time inventory and total earnings. Let's list a new crop: 200 kg of Crisp Red Pears at ₹120 per kg. Upon submission, the Express backend validates inputs and stores the record in our SQLite database."

---

### Scene 4: Buyer Discovery & Search (1:15 – 1:40)
- **Visual on Screen:**
  - Click user chip -> click **"Sign Out"**.
  - Click **"Quick Demo Login"** -> Select **Buyer Anita**.
  - Anita is redirected to the **Marketplace**.
  - Type `"Pears"` into the search bar: instant debounced filter displays the newly added product!
  - Switch categories: Click `"Fruits"` and `"Vegetables"` pills to show smooth filtering.
  - Return to `"Pears"`: highlight that the card displays Farmer Ramesh's name, Nashik location, and "200 kg available".
- **Presenter Narration (Member 3):**
  > "Now, we switch to our buyer, Anita Sharma. Navigating to the Marketplace, Anita searches for 'Pears'. Notice how the listing Farmer Ramesh just created is immediately discoverable with live stock indicators and transparent farm origin details."

---

### Scene 5: Direct Order Placement & Atomic Stock Deduction (1:40 – 2:05)
- **Visual on Screen:**
  - Click **"Direct Order"** on the Pears card.
  - Order modal opens with live price calculations.
  - Click the `+5` quantity stepper to increase order quantity to **25 kg**.
  - Highlight the subtotal preview updating to **₹3,000.00** (`25 kg × ₹120`).
  - Delivery address is pre-filled from Anita's profile (`Baner, Pune`).
  - Click **"Confirm Direct Order"**.
  - Green toast appears: *"Order #4 placed successfully!"*
  - Anita is redirected to **"My Farm Direct Orders"** where Order #4 appears with status badge **"Pending"**.
  - Quick switch back to Marketplace: show that available stock on Pears has automatically reduced from **200 kg to 175 kg**!
- **Presenter Narration (Member 3):**
  > "Anita orders 25 kg. Behind the scenes, our Express server executes an atomic SQLite database transaction: it locks the record, verifies stock sufficiency, computes the total on the backend, deducts the inventory from 200 to 175 kg, and records the pending order."

---

### Scene 6: Farmer Order Acceptance & Dispatch (2:05 – 2:25)
- **Visual on Screen:**
  - Switch back to Farmer Ramesh's account.
  - Open **Farmer Dashboard** -> Click **"Incoming Customer Orders"** tab.
  - Order #4 is visible with Buyer Anita's name, phone, address, and total amount of ₹3,000.
  - In the Action column, change status from `Pending` to `Accepted`.
  - Toast notification confirms: *"Order #4 status updated to Accepted"*.
- **Presenter Narration (Member 2):**
  > "Back on Farmer Ramesh's dashboard, the incoming order from Anita is instantly visible. Ramesh confirms the order by updating its status to 'Accepted'. Our role-based authorization ensures only the owning farmer can manage this order."

---

### Scene 7: Buyer Verification & Architecture Summary (2:25 – 2:45)
- **Visual on Screen:**
  - Switch back to Buyer Anita's "My Orders" view: Order #4 status pill has changed from amber "Pending" to blue **"Accepted"**.
  - Show the terminal briefly displaying the clean `19 PASSED` automated integration test run.
  - Return to the FarmDirect homepage.
- **Presenter Narration (Member 4):**
  > "Anita immediately sees the updated 'Accepted' status on her orders page. The entire application runs on Node.js, Express, and SQLite with zero external dependencies, accompanied by 19 automated integration tests and a complete Postman collection. FarmDirect creates a win-win ecosystem for Indian agriculture. Thank you for your time and evaluation!"

---

## Video Recording Checklist for Team
1. Start local server with `npm start` at `http://localhost:5000`.
2. Clear browser cache and ensure screen resolution is set to 1920x1080 (1080p).
3. Use OBS Studio or Windows Snipping Tool screen recorder.
4. Keep the pace crisp, confident, and professional.

