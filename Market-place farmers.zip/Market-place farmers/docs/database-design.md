# FarmDirect — Database Design Specification
**Engine:** SQLite3  
**Database File:** `database/marketplace.db`  
**Configuration:** `PRAGMA foreign_keys = ON;`

---

## 1. Schema Definition (DDL)

```sql
-- 1. Users Table
CREATE TABLE IF NOT EXISTS users (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  name TEXT NOT NULL,
  email TEXT NOT NULL UNIQUE,
  password_hash TEXT NOT NULL,
  role TEXT NOT NULL CHECK(role IN ('farmer', 'buyer', 'admin')),
  phone TEXT,
  address TEXT,
  created_at DATETIME DEFAULT CURRENT_TIMESTAMP
);

-- 2. Products Table
CREATE TABLE IF NOT EXISTS products (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  farmer_id INTEGER NOT NULL,
  name TEXT NOT NULL,
  category TEXT NOT NULL,
  price REAL NOT NULL CHECK(price >= 0),
  quantity REAL NOT NULL CHECK(quantity >= 0),
  unit TEXT NOT NULL DEFAULT 'kg',
  description TEXT,
  image_url TEXT,
  created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY (farmer_id) REFERENCES users(id) ON DELETE CASCADE
);

-- 3. Orders Table
CREATE TABLE IF NOT EXISTS orders (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  buyer_id INTEGER NOT NULL,
  product_id INTEGER NOT NULL,
  quantity REAL NOT NULL CHECK(quantity > 0),
  total_price REAL NOT NULL,
  status TEXT NOT NULL DEFAULT 'Pending' 
    CHECK(status IN ('Pending', 'Accepted', 'Rejected', 'Shipped', 'Completed', 'Cancelled')),
  delivery_address TEXT,
  notes TEXT,
  created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY (buyer_id) REFERENCES users(id) ON DELETE CASCADE,
  FOREIGN KEY (product_id) REFERENCES products(id) ON DELETE CASCADE
);

-- Indexes for Query Optimization
CREATE INDEX IF NOT EXISTS idx_products_category ON products(category);
CREATE INDEX IF NOT EXISTS idx_products_farmer ON products(farmer_id);
CREATE INDEX IF NOT EXISTS idx_orders_buyer ON orders(buyer_id);
CREATE INDEX IF NOT EXISTS idx_orders_product ON orders(product_id);
```

---

## 2. Table Data Dictionaries

### Table: `users`
| Column | Type | Constraints | Description |
| :--- | :--- | :--- | :--- |
| `id` | INTEGER | PRIMARY KEY, AUTOINCREMENT | Unique user identifier |
| `name` | TEXT | NOT NULL | User / Farm full display name |
| `email` | TEXT | NOT NULL, UNIQUE | User login email address |
| `password_hash` | TEXT | NOT NULL | 60-character bcrypt hash |
| `role` | TEXT | NOT NULL, CHECK in ('farmer', 'buyer', 'admin') | Platform authorization role |
| `phone` | TEXT | NULLABLE | Contact telephone number |
| `address` | TEXT | NULLABLE | Farm or delivery street address |
| `created_at` | DATETIME | DEFAULT CURRENT_TIMESTAMP | Registration timestamp |

### Table: `products`
| Column | Type | Constraints | Description |
| :--- | :--- | :--- | :--- |
| `id` | INTEGER | PRIMARY KEY, AUTOINCREMENT | Unique crop listing ID |
| `farmer_id` | INTEGER | NOT NULL, FK -> users(id) | Listing owner farmer |
| `name` | TEXT | NOT NULL | Agricultural produce name |
| `category` | TEXT | NOT NULL | Vegetables, Fruits, Grains, etc. |
| `price` | REAL | NOT NULL, CHECK(price >= 0) | Unit price in INR (₹) |
| `quantity` | REAL | NOT NULL, CHECK(quantity >= 0) | Stock quantity currently available |
| `unit` | TEXT | NOT NULL, DEFAULT 'kg' | Unit of measure (kg, quintal, etc.) |
| `description` | TEXT | NULLABLE | Crop quality, farming methods |
| `image_url` | TEXT | NULLABLE | Direct web URL to produce image |
| `created_at` | DATETIME | DEFAULT CURRENT_TIMESTAMP | Listing creation timestamp |

### Table: `orders`
| Column | Type | Constraints | Description |
| :--- | :--- | :--- | :--- |
| `id` | INTEGER | PRIMARY KEY, AUTOINCREMENT | Unique order reference number |
| `buyer_id` | INTEGER | NOT NULL, FK -> users(id) | Purchasing buyer ID |
| `product_id` | INTEGER | NOT NULL, FK -> products(id) | Purchased produce ID |
| `quantity` | REAL | NOT NULL, CHECK(quantity > 0) | Ordered quantity in product units |
| `total_price` | REAL | NOT NULL | Backend calculated cost (₹) |
| `status` | TEXT | NOT NULL, DEFAULT 'Pending' | Order fulfillment lifecycle stage |
| `delivery_address` | TEXT | NULLABLE | Destination location |
| `notes` | TEXT | NULLABLE | Special delivery packing instructions |
| `created_at` | DATETIME | DEFAULT CURRENT_TIMESTAMP | Order submission timestamp |

---

## 3. Concurrency & ACID Transaction Design
To prevent inventory race conditions where two simultaneous buyers attempt to purchase the same remaining stock, the backend uses **SQLite Immediate Transactions**:

```javascript
await exec('BEGIN IMMEDIATE TRANSACTION');
try {
  // Step 1: Read current stock with exclusive lock
  const product = await get('SELECT * FROM products WHERE id = ?', [product_id]);
  
  // Step 2: Validate stock
  if (product.quantity < requestedQty) {
    await exec('ROLLBACK');
    throw new Error('Insufficient inventory');
  }

  // Step 3: Decrement stock
  await run('UPDATE products SET quantity = quantity - ? WHERE id = ?', [requestedQty, product_id]);

  // Step 4: Insert order record
  await run('INSERT INTO orders (...) VALUES (...)', [...]);

  // Step 5: Atomically commit both changes
  await exec('COMMIT');
} catch (err) {
  await exec('ROLLBACK');
  throw err;
}
```

This guarantees that:
1. Product inventory can never drop below zero.
2. Orders are never recorded without corresponding stock reduction.
3. If an error occurs midway, all changes are rolled back automatically.

