# FarmDirect — Four-Member Hackathon Team Contribution Document
**Problem Statement ID:** HACK-P309  
**Team Composition:** 4 Students (Same Section, Department of Computer Science & Engineering)  
**Project:** FarmDirect — Direct Agricultural Marketplace  

---

## Team Overview & Work Distribution Matrix

| Team Member | Core Focus Area | Primary Artifacts & Deliverables | Hackathon Viva / Defense Topic |
| :--- | :--- | :--- | :--- |
| **Member 1** | **Frontend UI/UX & Responsive Views** | `public/index.html`, `public/style.css`, DOM rendering in `app.js` | UI architecture, responsive design, color theory, accessibility, and client-side validation. |
| **Member 2** | **Backend Server, Authentication & Middleware** | `server.js`, `routes/auth.js`, `middleware/authMiddleware.js`, `.env` | Express server lifecycle, JWT token generation/verification, bcrypt hashing, and route protection. |
| **Member 3** | **Database Architecture & REST Endpoints** | `database/db.js`, `database/seed.js`, `routes/products.js`, `routes/orders.js` | SQLite schema design, relational constraints, ACID transactions, and atomic inventory reduction. |
| **Member 4** | **API Testing, Integration, Postman & Demo Video** | `test/api-test.js`, `postman_collection.json`, `docs/*`, Demo Script | Automated test suites, Postman collection, end-to-end integration, and demo presentation. |

---

## Detailed Member Responsibilities & Presentation Explanations

### Member 1: Frontend Design and Website Pages
- **Responsibilities:**
  1. Designed the agricultural color system (deep forest greens `#1b4332`, leaf greens `#2d6a4f`, earthy backgrounds `#f8faf7`, and harvest gold accents `#d97706`).
  2. Implemented responsive layout mechanics for desktop, tablet, and mobile with sticky header and mobile navigation drawer.
  3. Built modular single-page views:
     - Hero section with live statistics and mission highlights.
     - 4-step "How It Works" visual process flow.
     - Dual-column benefits comparison for farmers vs. buyers.
     - Agricultural marketplace cards with stock alert badges.
     - Farmer dashboard table views and Buyer order tracking cards.
  4. Developed modal interfaces for Authentication, Direct Order Placement (with interactive stepper and live subtotal calculator), and Product Creation.
  5. Implemented dynamic toast notification system and empty state graphics.
- **Viva Defense Points to Explain to Judges:**
  - *"I ensured that zero CSS frameworks were needed, minimizing bundle size and external dependencies while achieving 100% responsiveness with CSS Grid and Flexbox."*
  - *"I designed the order modal with live price recalculation so buyers see the exact subtotal before committing the transaction."*

---

### Member 2: Backend Server, Authentication & Middleware
- **Responsibilities:**
  1. Bootstrapped the Express.js application with CORS, JSON body parsing, and request logging.
  2. Implemented stateless JSON Web Token (JWT) architecture with 24-hour expiration.
  3. Created `authMiddleware.js` containing `authenticateToken` and higher-order `requireRole(...roles)` guards.
  4. Engineered `/api/auth/register` with email regex verification, minimum password length enforcement, duplicate email detection (409 Conflict), and public admin registration prevention.
  5. Implemented `/api/auth/login` utilizing `bcryptjs` for secure password comparison without ever storing or returning plaintext secrets.
  6. Configured centralized error handling middleware and graceful server fallback.
- **Viva Defense Points to Explain to Judges:**
  - *"Our authentication system is stateless: user identity and role are embedded in cryptographically signed JWT tokens, allowing easy horizontal scaling."*
  - *"We protect against credential scraping by enforcing 10 rounds of bcrypt salting and stripping password hashes from all outbound API responses."*

---

### Member 3: Database Architecture, Product APIs & Order APIs
- **Responsibilities:**
  1. Designed normalized SQLite relational database schema across `users`, `products`, and `orders` with foreign keys enabled (`PRAGMA foreign_keys = ON;`).
  2. Created promise-wrapped async helpers for SQLite (`run`, `get`, `all`, `exec`) in `database/db.js`.
  3. Developed `database/seed.js` providing realistic initial crop inventory across 6 categories and pre-configured demo users.
  4. Built the complete CRUD product endpoints (`GET`, `POST`, `PUT`, `DELETE` `/api/products`) with strict farmer ownership validation.
  5. Implemented order creation endpoint (`POST /api/orders`) using **SQLite transactions (`BEGIN IMMEDIATE TRANSACTION`, `COMMIT`, `ROLLBACK`)** to ensure atomic stock decrementing and prevent overselling.
  6. Engineered order lifecycle state machine (`Pending` -> `Accepted` -> `Shipped` -> `Completed`) with stock restoration on cancellation.
- **Viva Defense Points to Explain to Judges:**
  - *"To eliminate inventory race conditions, we wrapped order creation in SQLite immediate transactions, guaranteeing that two concurrent buyers can never oversell the same crop."*
  - *"All order totals are computed strictly on the backend based on database pricing; frontend price estimates are never trusted."*

---

### Member 4: API Testing, Integration, Documentation & Demo Video
- **Responsibilities:**
  1. Created standalone automated test suite `test/api-test.js` validating 19 test cases without third-party test runners.
  2. Authored full `postman_collection.json` containing pre-configured requests, environment variables, and token capture scripts.
  3. Tested edge cases: duplicate registrations, unauthorized modifications, negative stock requests, and data persistence after server restart.
  4. Authored comprehensive hackathon project documentation files (`project-documentation.md`, `api-documentation.md`, `database-design.md`, `README.md`).
  5. Scripted and timed the 2-3 minute prototype demonstration video with exact screen directions.
- **Viva Defense Points to Explain to Judges:**
  - *"We wrote an automated test runner that executes 19 integration tests against the live server, covering authentication, authorization, stock deduction, and filtering."*
  - *"The entire project was tested for zero-setup execution, allowing evaluators to verify the complete farmer-to-buyer workflow in under two minutes."*

---

## Team Sign-off
All four members contributed equally to the architecture, codebase, and evaluation readiness of **FarmDirect (HACK-P309)**.

