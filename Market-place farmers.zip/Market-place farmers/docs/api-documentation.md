# FarmDirect — RESTful API Documentation
**Base URL:** `http://localhost:5000/api`  
**Authentication Scheme:** Bearer Token via Header `Authorization: Bearer <token>`  
**Data Format:** `application/json`

---

## 1. System Health

### `GET /api/health`
Checks server status, database readiness, and process uptime.
- **Access:** Public
- **Response `200 OK`:**
```json
{
  "status": "healthy",
  "project": "FarmDirect - Farmer Marketplace",
  "problemStatementId": "HACK-P309",
  "timestamp": "2026-10-31T11:15:00.000Z",
  "uptime": 142.5
}
```

---

## 2. Authentication Endpoints

### `POST /api/auth/register`
Registers a new user (farmer or buyer).
- **Access:** Public
- **Request Body:**
```json
{
  "name": "Farmer Ramesh Patel",
  "email": "farmer.ramesh@farmdirect.com",
  "password": "Farmer@123",
  "role": "farmer",
  "phone": "+91 98230 11223",
  "address": "Village Ozar, Nashik, Maharashtra"
}
```
- **Responses:**
  - `201 Created`: User registered and JWT token issued.
  - `400 Bad Request`: Validation failure (short password, invalid email, illegal role).
  - `409 Conflict`: Email already exists.

### `POST /api/auth/login`
Authenticates existing user credentials.
- **Access:** Public
- **Request Body:**
```json
{
  "email": "farmer.ramesh@farmdirect.com",
  "password": "Farmer@123"
}
```
- **Response `200 OK`:**
```json
{
  "success": true,
  "message": "Logged in successfully!",
  "token": "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9...",
  "user": {
    "id": 1,
    "name": "Farmer Ramesh Patel",
    "email": "farmer.ramesh@farmdirect.com",
    "role": "farmer",
    "phone": "+91 98230 11223",
    "address": "Village Ozar, Nashik, Maharashtra"
  }
}
```
- **Response `401 Unauthorized`:** Invalid email or password.

### `GET /api/auth/me`
Retrieves the authenticated profile.
- **Access:** Protected (`farmer`, `buyer`, `admin`)
- **Headers:** `Authorization: Bearer <token>`
- **Response `200 OK`:** User profile object.

---

## 3. Product Endpoints

### `GET /api/products`
Retrieves produce catalog with optional filters.
- **Access:** Public
- **Query Parameters:**
  - `search`: Filter by product name or description
  - `category`: Filter by category (e.g. `Vegetables`, `Fruits`, `Grains`, `Pulses`, `Dairy`, `Spices`)
  - `farmer_id`: Filter by specific farmer ID
  - `minPrice`, `maxPrice`: Numerical price boundaries
- **Response `200 OK`:**
```json
{
  "success": true,
  "count": 10,
  "products": [
    {
      "id": 1,
      "farmer_id": 1,
      "name": "Organic Vine-Ripened Tomatoes",
      "category": "Vegetables",
      "price": 35.0,
      "quantity": 450,
      "unit": "kg",
      "description": "Naturally grown farm-fresh red tomatoes...",
      "image_url": "https://images.unsplash.com/...",
      "farmer_name": "Ramesh Patel (Greenfield Organics)",
      "farmer_phone": "+91 98230 11223",
      "farmer_location": "Village Ozar, Nashik, Maharashtra"
    }
  ]
}
```

### `GET /api/products/:id`
Retrieves a specific crop listing by ID.
- **Access:** Public
- **Response `200 OK`** or `404 Not Found`.

### `POST /api/products`
Creates a new produce listing.
- **Access:** Protected (`farmer`, `admin`)
- **Headers:** `Authorization: Bearer <farmerToken>`
- **Request Body:**
```json
{
  "name": "Fresh Organic Shimla Apples",
  "category": "Fruits",
  "price": 140.0,
  "quantity": 300,
  "unit": "kg",
  "description": "Sweet, crisp apples directly from high altitude orchard.",
  "image_url": "https://images.unsplash.com/..."
}
```
- **Response `201 Created`:** Returns created product record.
- **Response `403 Forbidden`:** If attempted by a buyer.

### `PUT /api/products/:id`
Updates an existing produce listing.
- **Access:** Protected (Owning `farmer` or `admin`)
- **Request Body:** Any subset of `{ name, category, price, quantity, unit, description, image_url }`.
- **Response `200 OK`** or `403 Forbidden` if user does not own the listing.

### `DELETE /api/products/:id`
Deletes a produce listing.
- **Access:** Protected (Owning `farmer` or `admin`).
- **Response `200 OK`:** Product deleted.

---

## 4. Order Endpoints

### `POST /api/orders`
Places a direct order with stock validation and atomic SQLite transactions.
- **Access:** Protected (`buyer`, `admin`)
- **Headers:** `Authorization: Bearer <buyerToken>`
- **Request Body:**
```json
{
  "product_id": 1,
  "quantity": 25,
  "delivery_address": "B-402 Green Meadows, Baner, Pune",
  "notes": "Pack in sturdy crates please"
}
```
- **Business Logic:**
  1. Checks if `product.quantity >= quantity`.
  2. Calculates backend price: `total_price = quantity * product.price`.
  3. Updates stock: `product.quantity = product.quantity - quantity`.
  4. Inserts row into `orders` table.
- **Response `201 Created`:**
```json
{
  "success": true,
  "message": "Order placed successfully!",
  "order": {
    "id": 4,
    "buyer_id": 3,
    "product_id": 1,
    "quantity": 25,
    "total_price": 875.0,
    "status": "Pending",
    "delivery_address": "B-402 Green Meadows, Baner, Pune",
    "product_name": "Organic Vine-Ripened Tomatoes",
    "farmer_name": "Ramesh Patel (Greenfield Organics)"
  },
  "remainingStock": 425
}
```
- **Response `400 Bad Request`:** Insufficient stock or negative quantity.

### `GET /api/orders/my`
Retrieves relevant orders based on the caller's role:
- If `buyer`: Returns all orders placed by the user.
- If `farmer`: Returns incoming orders for all products listed by the farmer.
- If `admin`: Returns all platform orders.
- **Access:** Protected (`buyer`, `farmer`, `admin`).
- **Response `200 OK`:** Array of order objects.

### `PATCH /api/orders/:id/status`
Updates status of an order.
- **Access:** Protected (`farmer`, `buyer`, `admin`)
- **Request Body:**
```json
{
  "status": "Accepted"
}
```
- **Allowed Transitions:**
  - Farmers: `Pending` -> `Accepted` -> `Shipped` -> `Completed` or `Rejected`.
  - Buyers: `Pending` -> `Cancelled`.
- **Note:** If an order is transitioned to `Cancelled` or `Rejected`, previously deducted stock is automatically restored back to the product inventory.

---

## 5. Admin Endpoints

### `GET /api/admin/stats`
- **Access:** Protected (`admin`)
- **Response `200 OK`:** Counts for total users, farmers, buyers, listed products, orders, and total gross revenue.

### `GET /api/admin/users`
- **Access:** Protected (`admin`)
- **Response `200 OK`:** List of all registered users without password hashes.

### `POST /api/admin/reset-demo`
- **Access:** Protected (`admin`)
- **Response `200 OK`:** Resets database tables and re-seeds original demo records.

