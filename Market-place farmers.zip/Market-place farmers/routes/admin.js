const express = require('express');
const router = express.Router();
const { get, all } = require('../database/db');
const { seedData } = require('../database/seed');
const { authenticateToken, requireRole } = require('../middleware/authMiddleware');

/**
 * GET /api/admin/stats
 * Overview numbers for admin dashboard
 */
router.get('/stats', authenticateToken, requireRole('admin'), async (req, res, next) => {
  try {
    const totalUsers = await get('SELECT COUNT(*) as count FROM users');
    const totalFarmers = await get("SELECT COUNT(*) as count FROM users WHERE role = 'farmer'");
    const totalBuyers = await get("SELECT COUNT(*) as count FROM users WHERE role = 'buyer'");
    const totalProducts = await get('SELECT COUNT(*) as count FROM products');
    const totalOrders = await get('SELECT COUNT(*) as count FROM orders');
    const totalRevenue = await get("SELECT COALESCE(SUM(total_price), 0) as total FROM orders WHERE status NOT IN ('Cancelled', 'Rejected')");

    return res.status(200).json({
      success: true,
      stats: {
        totalUsers: totalUsers.count,
        totalFarmers: totalFarmers.count,
        totalBuyers: totalBuyers.count,
        totalProducts: totalProducts.count,
        totalOrders: totalOrders.count,
        totalRevenue: Math.round(totalRevenue.total * 100) / 100
      }
    });
  } catch (err) {
    next(err);
  }
});

/**
 * GET /api/admin/users
 * View all registered users (excluding password hashes)
 */
router.get('/users', authenticateToken, requireRole('admin'), async (req, res, next) => {
  try {
    const users = await all(
      'SELECT id, name, email, role, phone, address, created_at FROM users ORDER BY id DESC'
    );
    return res.status(200).json({
      success: true,
      users
    });
  } catch (err) {
    next(err);
  }
});

/**
 * POST /api/admin/reset-demo
 * Safely resets database to clean seed state for live hackathon presentation
 */
router.post('/reset-demo', authenticateToken, requireRole('admin'), async (req, res, next) => {
  try {
    await seedData(true);
    return res.status(200).json({
      success: true,
      message: 'Demo database has been successfully reset to original seed state.'
    });
  } catch (err) {
    next(err);
  }
});

module.exports = router;

