const express = require('express');
const router = express.Router();
const { run, get, all, exec } = require('../database/db');
const { authenticateToken, requireRole } = require('../middleware/authMiddleware');

const VALID_STATUSES = ['Pending', 'Accepted', 'Rejected', 'Shipped', 'Completed', 'Cancelled'];

/**
 * POST /api/orders
 * Buyer places a new order with stock validation and atomic transaction
 */
router.post('/', authenticateToken, requireRole('buyer', 'admin'), async (req, res, next) => {
  try {
    const { product_id, quantity, delivery_address, notes } = req.body;

    if (!product_id) {
      return res.status(400).json({
        success: false,
        message: 'Product ID is required.'
      });
    }

    const orderQty = parseFloat(quantity);
    if (isNaN(orderQty) || orderQty <= 0) {
      return res.status(400).json({
        success: false,
        message: 'Order quantity must be a positive number greater than zero.'
      });
    }

    const address = (delivery_address && delivery_address.trim()) 
      ? delivery_address.trim() 
      : (req.user.address || 'Address provided at checkout');

    // Begin database transaction to ensure atomicity
    await exec('BEGIN IMMEDIATE TRANSACTION');

    try {
      // 1. Fetch latest product info inside transaction
      const product = await get('SELECT * FROM products WHERE id = ?', [product_id]);

      if (!product) {
        await exec('ROLLBACK');
        return res.status(404).json({
          success: false,
          message: 'Product not found.'
        });
      }

      // Check if buyer is trying to buy their own product if they are also registered as farmer
      if (product.farmer_id === req.user.id) {
        await exec('ROLLBACK');
        return res.status(400).json({
          success: false,
          message: 'You cannot purchase your own listed produce.'
        });
      }

      // 2. Validate available stock
      if (product.quantity < orderQty) {
        await exec('ROLLBACK');
        return res.status(400).json({
          success: false,
          message: `Insufficient stock available. Requested: ${orderQty} ${product.unit}, Available: ${product.quantity} ${product.unit}.`
        });
      }

      // 3. Compute backend price calculation (Never trust frontend price calculations)
      const totalPrice = Math.round((orderQty * product.price) * 100) / 100;
      const remainingStock = Math.round((product.quantity - orderQty) * 100) / 100;

      // 4. Reduce stock
      await run('UPDATE products SET quantity = ? WHERE id = ?', [remainingStock, product_id]);

      // 5. Create order
      const orderResult = await run(
        `INSERT INTO orders (buyer_id, product_id, quantity, total_price, status, delivery_address, notes)
         VALUES (?, ?, ?, ?, 'Pending', ?, ?)`,
        [req.user.id, product_id, orderQty, totalPrice, address, notes ? notes.trim() : '']
      );

      // Commit transaction
      await exec('COMMIT');

      // Fetch created order with all details
      const createdOrder = await get(
        `SELECT 
          o.id,
          o.buyer_id,
          o.product_id,
          o.quantity,
          o.total_price,
          o.status,
          o.delivery_address,
          o.notes,
          o.created_at,
          p.name as product_name,
          p.category as product_category,
          p.unit as product_unit,
          p.price as unit_price,
          p.image_url as product_image,
          u_farmer.name as farmer_name,
          u_farmer.phone as farmer_phone
        FROM orders o
        JOIN products p ON o.product_id = p.id
        JOIN users u_farmer ON p.farmer_id = u_farmer.id
        WHERE o.id = ?`,
        [orderResult.lastID]
      );

      return res.status(201).json({
        success: true,
        message: 'Order placed successfully!',
        order: createdOrder,
        remainingStock
      });
    } catch (err) {
      await exec('ROLLBACK');
      throw err;
    }
  } catch (err) {
    next(err);
  }
});

/**
 * GET /api/orders/my
 * Returns orders relevant to the authenticated user:
 * - Buyers see orders they placed
 * - Farmers see orders received for their crops
 * - Admins see all orders
 */
router.get('/my', authenticateToken, async (req, res, next) => {
  try {
    let query = '';
    let params = [];

    if (req.user.role === 'buyer') {
      query = `
        SELECT 
          o.id,
          o.buyer_id,
          o.product_id,
          o.quantity,
          o.total_price,
          o.status,
          o.delivery_address,
          o.notes,
          o.created_at,
          p.name as product_name,
          p.category as product_category,
          p.unit as product_unit,
          p.price as unit_price,
          p.image_url as product_image,
          u_farmer.name as farmer_name,
          u_farmer.phone as farmer_phone,
          u_farmer.address as farmer_address
        FROM orders o
        JOIN products p ON o.product_id = p.id
        JOIN users u_farmer ON p.farmer_id = u_farmer.id
        WHERE o.buyer_id = ?
        ORDER BY o.id DESC
      `;
      params = [req.user.id];
    } else if (req.user.role === 'farmer') {
      query = `
        SELECT 
          o.id,
          o.buyer_id,
          o.product_id,
          o.quantity,
          o.total_price,
          o.status,
          o.delivery_address,
          o.notes,
          o.created_at,
          p.name as product_name,
          p.category as product_category,
          p.unit as product_unit,
          p.price as unit_price,
          p.image_url as product_image,
          u_buyer.name as buyer_name,
          u_buyer.email as buyer_email,
          u_buyer.phone as buyer_phone
        FROM orders o
        JOIN products p ON o.product_id = p.id
        JOIN users u_buyer ON o.buyer_id = u_buyer.id
        WHERE p.farmer_id = ?
        ORDER BY o.id DESC
      `;
      params = [req.user.id];
    } else {
      // Admin sees all
      query = `
        SELECT 
          o.id,
          o.buyer_id,
          o.product_id,
          o.quantity,
          o.total_price,
          o.status,
          o.delivery_address,
          o.notes,
          o.created_at,
          p.name as product_name,
          p.unit as product_unit,
          p.price as unit_price,
          p.image_url as product_image,
          u_buyer.name as buyer_name,
          u_farmer.name as farmer_name
        FROM orders o
        JOIN products p ON o.product_id = p.id
        JOIN users u_buyer ON o.buyer_id = u_buyer.id
        JOIN users u_farmer ON p.farmer_id = u_farmer.id
        ORDER BY o.id DESC
      `;
    }

    const orders = await all(query, params);

    return res.status(200).json({
      success: true,
      count: orders.length,
      orders
    });
  } catch (err) {
    next(err);
  }
});

/**
 * PATCH /api/orders/:id/status
 * Updates status of an order (e.g. Pending -> Accepted -> Shipped -> Completed)
 */
router.patch('/:id/status', authenticateToken, async (req, res, next) => {
  try {
    const orderId = req.params.id;
    const { status } = req.body;

    if (!status || !VALID_STATUSES.includes(status)) {
      return res.status(400).json({
        success: false,
        message: `Invalid status. Must be one of: ${VALID_STATUSES.join(', ')}`
      });
    }

    const order = await get(
      `SELECT o.*, p.farmer_id, p.name as product_name, p.quantity as current_stock 
       FROM orders o 
       JOIN products p ON o.product_id = p.id 
       WHERE o.id = ?`,
      [orderId]
    );

    if (!order) {
      return res.status(404).json({
        success: false,
        message: 'Order not found.'
      });
    }

    // Role and permission checks
    if (req.user.role === 'buyer') {
      if (order.buyer_id !== req.user.id) {
        return res.status(403).json({
          success: false,
          message: 'Access denied: You can only update your own orders.'
        });
      }
      if (status !== 'Cancelled') {
        return res.status(403).json({
          success: false,
          message: 'Buyers can only cancel pending orders.'
        });
      }
      if (order.status !== 'Pending') {
        return res.status(400).json({
          success: false,
          message: `Cannot cancel order with current status "${order.status}". Contact the farmer directly.`
        });
      }
    } else if (req.user.role === 'farmer') {
      if (order.farmer_id !== req.user.id && req.user.role !== 'admin') {
        return res.status(403).json({
          success: false,
          message: 'Access denied: You can only update orders for your own products.'
        });
      }
    }

    // If order is transitioning to Cancelled or Rejected from a non-cancelled state, restore product stock
    if (['Cancelled', 'Rejected'].includes(status) && !['Cancelled', 'Rejected'].includes(order.status)) {
      await run(
        'UPDATE products SET quantity = quantity + ? WHERE id = ?',
        [order.quantity, order.product_id]
      );
    }

    // Update status
    await run('UPDATE orders SET status = ? WHERE id = ?', [status, orderId]);

    const updatedOrder = await get('SELECT * FROM orders WHERE id = ?', [orderId]);

    return res.status(200).json({
      success: true,
      message: `Order status updated to "${status}".`,
      order: updatedOrder
    });
  } catch (err) {
    next(err);
  }
});

module.exports = router;

