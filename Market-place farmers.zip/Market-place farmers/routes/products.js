const express = require('express');
const router = express.Router();
const { run, get, all } = require('../database/db');
const { authenticateToken, requireRole } = require('../middleware/authMiddleware');

const DEFAULT_IMAGE = 'https://images.unsplash.com/photo-1542838132-92c53300491e?auto=format&fit=crop&w=600&q=80';

/**
 * GET /api/products
 * Fetch products with optional filtering by search query, category, price range, or farmer
 */
router.get('/', async (req, res, next) => {
  try {
    const { search, category, minPrice, maxPrice, farmer_id } = req.query;

    let query = `
      SELECT 
        p.id,
        p.farmer_id,
        p.name,
        p.category,
        p.price,
        p.quantity,
        p.unit,
        p.description,
        p.image_url,
        p.created_at,
        u.name as farmer_name,
        u.email as farmer_email,
        u.phone as farmer_phone,
        u.address as farmer_location
      FROM products p
      JOIN users u ON p.farmer_id = u.id
      WHERE 1=1
    `;
    const params = [];

    if (search && search.trim() !== '') {
      query += ` AND (LOWER(p.name) LIKE ? OR LOWER(p.description) LIKE ?)`;
      const term = `%${search.trim().toLowerCase()}%`;
      params.push(term, term);
    }

    if (category && category.trim() !== '' && category.toLowerCase() !== 'all') {
      query += ` AND LOWER(p.category) = ?`;
      params.push(category.trim().toLowerCase());
    }

    if (farmer_id) {
      query += ` AND p.farmer_id = ?`;
      params.push(farmer_id);
    }

    if (minPrice && !isNaN(Number(minPrice))) {
      query += ` AND p.price >= ?`;
      params.push(Number(minPrice));
    }

    if (maxPrice && !isNaN(Number(maxPrice))) {
      query += ` AND p.price <= ?`;
      params.push(Number(maxPrice));
    }

    query += ` ORDER BY p.id DESC`;

    const products = await all(query, params);

    return res.status(200).json({
      success: true,
      count: products.length,
      products
    });
  } catch (err) {
    next(err);
  }
});

/**
 * GET /api/products/:id
 * Retrieve a specific product by ID
 */
router.get('/:id', async (req, res, next) => {
  try {
    const productId = req.params.id;

    const product = await get(
      `SELECT 
        p.id,
        p.farmer_id,
        p.name,
        p.category,
        p.price,
        p.quantity,
        p.unit,
        p.description,
        p.image_url,
        p.created_at,
        u.name as farmer_name,
        u.email as farmer_email,
        u.phone as farmer_phone,
        u.address as farmer_location
      FROM products p
      JOIN users u ON p.farmer_id = u.id
      WHERE p.id = ?`,
      [productId]
    );

    if (!product) {
      return res.status(404).json({
        success: false,
        message: 'Product not found.'
      });
    }

    return res.status(200).json({
      success: true,
      product
    });
  } catch (err) {
    next(err);
  }
});

/**
 * POST /api/products
 * Farmer creates a new product listing
 */
router.post('/', authenticateToken, requireRole('farmer', 'admin'), async (req, res, next) => {
  try {
    const { name, category, price, quantity, unit, description, image_url } = req.body;

    if (!name || typeof name !== 'string' || name.trim().length === 0) {
      return res.status(400).json({
        success: false,
        message: 'Product name is required.'
      });
    }

    if (!category || typeof category !== 'string' || category.trim().length === 0) {
      return res.status(400).json({
        success: false,
        message: 'Product category is required.'
      });
    }

    const parsedPrice = parseFloat(price);
    if (isNaN(parsedPrice) || parsedPrice <= 0) {
      return res.status(400).json({
        success: false,
        message: 'Price must be a valid positive number.'
      });
    }

    const parsedQuantity = parseFloat(quantity);
    if (isNaN(parsedQuantity) || parsedQuantity < 0) {
      return res.status(400).json({
        success: false,
        message: 'Quantity must be a valid non-negative number.'
      });
    }

    const finalUnit = (unit && typeof unit === 'string' && unit.trim()) ? unit.trim() : 'kg';
    const finalImage = (image_url && typeof image_url === 'string' && image_url.trim()) ? image_url.trim() : DEFAULT_IMAGE;

    const result = await run(
      `INSERT INTO products (farmer_id, name, category, price, quantity, unit, description, image_url)
       VALUES (?, ?, ?, ?, ?, ?, ?, ?)`,
      [
        req.user.id,
        name.trim(),
        category.trim(),
        parsedPrice,
        parsedQuantity,
        finalUnit,
        description ? description.trim() : '',
        finalImage
      ]
    );

    const createdProduct = await get(
      `SELECT p.*, u.name as farmer_name 
       FROM products p 
       JOIN users u ON p.farmer_id = u.id 
       WHERE p.id = ?`,
      [result.lastID]
    );

    return res.status(201).json({
      success: true,
      message: 'Product listed successfully!',
      product: createdProduct
    });
  } catch (err) {
    next(err);
  }
});

/**
 * PUT /api/products/:id
 * Farmer updates an existing product
 */
router.put('/:id', authenticateToken, requireRole('farmer', 'admin'), async (req, res, next) => {
  try {
    const productId = req.params.id;
    const existing = await get('SELECT * FROM products WHERE id = ?', [productId]);

    if (!existing) {
      return res.status(404).json({
        success: false,
        message: 'Product not found.'
      });
    }

    // Ownership check: Farmer can only edit their own products unless admin
    if (req.user.role !== 'admin' && existing.farmer_id !== req.user.id) {
      return res.status(403).json({
        success: false,
        message: 'Forbidden: You are not authorized to modify this product.'
      });
    }

    const { name, category, price, quantity, unit, description, image_url } = req.body;

    const updatedName = (name !== undefined && name !== null) ? String(name).trim() : existing.name;
    const updatedCategory = (category !== undefined && category !== null) ? String(category).trim() : existing.category;
    const updatedPrice = (price !== undefined && !isNaN(Number(price))) ? Number(price) : existing.price;
    const updatedQuantity = (quantity !== undefined && !isNaN(Number(quantity))) ? Number(quantity) : existing.quantity;
    const updatedUnit = (unit !== undefined && unit !== null) ? String(unit).trim() : existing.unit;
    const updatedDescription = (description !== undefined && description !== null) ? String(description).trim() : existing.description;
    const updatedImage = (image_url !== undefined && image_url !== null && image_url.trim() !== '') ? String(image_url).trim() : existing.image_url;

    if (updatedPrice <= 0) {
      return res.status(400).json({
        success: false,
        message: 'Price must be greater than zero.'
      });
    }

    if (updatedQuantity < 0) {
      return res.status(400).json({
        success: false,
        message: 'Quantity cannot be negative.'
      });
    }

    await run(
      `UPDATE products 
       SET name = ?, category = ?, price = ?, quantity = ?, unit = ?, description = ?, image_url = ?
       WHERE id = ?`,
      [updatedName, updatedCategory, updatedPrice, updatedQuantity, updatedUnit, updatedDescription, updatedImage, productId]
    );

    const updatedProduct = await get(
      `SELECT p.*, u.name as farmer_name 
       FROM products p 
       JOIN users u ON p.farmer_id = u.id 
       WHERE p.id = ?`,
      [productId]
    );

    return res.status(200).json({
      success: true,
      message: 'Product updated successfully!',
      product: updatedProduct
    });
  } catch (err) {
    next(err);
  }
});

/**
 * DELETE /api/products/:id
 * Farmer deletes a product listing
 */
router.delete('/:id', authenticateToken, requireRole('farmer', 'admin'), async (req, res, next) => {
  try {
    const productId = req.params.id;
    const existing = await get('SELECT * FROM products WHERE id = ?', [productId]);

    if (!existing) {
      return res.status(404).json({
        success: false,
        message: 'Product not found.'
      });
    }

    // Ownership check
    if (req.user.role !== 'admin' && existing.farmer_id !== req.user.id) {
      return res.status(403).json({
        success: false,
        message: 'Forbidden: You are not authorized to delete this product.'
      });
    }

    await run('DELETE FROM products WHERE id = ?', [productId]);

    return res.status(200).json({
      success: true,
      message: `Product "${existing.name}" has been deleted.`
    });
  } catch (err) {
    next(err);
  }
});

module.exports = router;

